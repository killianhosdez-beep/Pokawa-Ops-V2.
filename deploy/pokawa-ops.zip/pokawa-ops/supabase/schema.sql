-- =====================================================================
-- Pokawa Ops — schéma Supabase complet (à exécuter une fois dans SQL Editor)
-- Idempotent : peut être relancé sans casser les données existantes.
--
-- Principe de sécurité : les employés n'ont AUCUN droit d'écriture direct sur
-- les tables. Tout passe par des fonctions SECURITY DEFINER qui appliquent les
-- règles (quantité demandée intouchable, motif obligatoire, pas de double
-- validation). Même un employé qui contourne l'interface est bloqué ici.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null,
  role        text not null default 'employee' check (role in ('admin','manager','employee')),
  active      boolean not null default true,
  created_at  timestamptz not null default now()
);

create table if not exists public.list_types (
  id          uuid primary key default gen_random_uuid(),
  name        text not null unique,
  color       text not null default '#0B3C5D',
  sort_order  int  not null default 0,
  active      boolean not null default true,
  created_at  timestamptz not null default now()
);

create table if not exists public.lists (
  id              uuid primary key default gen_random_uuid(),
  name            text not null,
  type_id         uuid references public.list_types(id),
  work_date       date not null default current_date,
  period          text not null default 'morning' check (period in ('morning','afternoon','evening','all_day')),
  due_time        time,
  instructions    text,
  surplus_policy  text not null default 'justify' check (surplus_policy in ('allow','justify')),
  status          text not null default 'draft' check (status in ('draft','published','closed')),
  created_by      uuid references public.profiles(id),
  created_at      timestamptz not null default now(),
  published_at    timestamptz,
  updated_at      timestamptz not null default now()
);
create index if not exists lists_work_date_idx on public.lists (work_date desc);

create table if not exists public.list_items (
  id             uuid primary key default gen_random_uuid(),
  list_id        uuid not null references public.lists(id) on delete cascade,
  product        text not null,
  requested_qty  numeric(12,3) not null check (requested_qty > 0),
  unit           text not null,
  comment        text,
  sort_order     int not null default 0
);
create index if not exists list_items_list_idx on public.list_items (list_id, sort_order);

-- Absence de ligne = « à faire ».
create table if not exists public.item_results (
  item_id              uuid primary key references public.list_items(id) on delete cascade,
  status               text not null default 'todo'
                       check (status in ('todo','in_progress','done','partial','to_fix','gap_accepted')),
  prepared_qty         numeric(12,3),
  missing_qty          numeric(12,3) not null default 0,
  surplus_qty          numeric(12,3) not null default 0,
  comment              text,
  manager_instruction  text,
  updated_by           uuid references public.profiles(id),
  updated_by_name      text,
  updated_at           timestamptz not null default now(),
  completed_by         uuid references public.profiles(id),
  completed_by_name    text,
  completed_at         timestamptz
);

-- Signalements d'écart.
create table if not exists public.reports (
  id               uuid primary key default gen_random_uuid(),
  item_id          uuid not null references public.list_items(id) on delete cascade,
  list_id          uuid not null references public.lists(id) on delete cascade,
  requested_qty    numeric(12,3) not null,
  prepared_qty     numeric(12,3) not null,
  missing_qty      numeric(12,3) not null,
  reason           text not null,
  comment          text,
  reported_by      uuid references public.profiles(id),
  reported_by_name text,
  reported_at      timestamptz not null default now(),
  status           text not null default 'open' check (status in ('open','resolved')),
  decision         text check (decision in ('complete','recheck','instruction','accept','close','completed')),
  decision_note    text,
  decided_by       uuid references public.profiles(id),
  decided_by_name  text,
  decided_at       timestamptz
);
create unique index if not exists reports_one_open_per_item on public.reports (item_id) where status = 'open';
create index if not exists reports_list_idx on public.reports (list_id);

create table if not exists public.audit_events (
  id          bigint generated always as identity primary key,
  at          timestamptz not null default now(),
  actor_id    uuid,
  actor_name  text,
  action      text not null,
  entity      text,
  entity_id   uuid,
  list_id     uuid,
  details     jsonb not null default '{}'::jsonb
);
create index if not exists audit_at_idx on public.audit_events (at desc);
create index if not exists audit_list_idx on public.audit_events (list_id);

-- ---------------------------------------------------------------------
-- Aides : rôle de l'utilisateur connecté
-- ---------------------------------------------------------------------
create or replace function public.app_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and active
$$;

create or replace function public.is_manager() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.app_role() in ('admin','manager'), false)
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.app_role() = 'admin', false)
$$;

create or replace function public.actor_name() returns text
language sql stable security definer set search_path = public as $$
  select full_name from public.profiles where id = auth.uid()
$$;

create or replace function public.log_event(p_action text, p_entity text, p_entity_id uuid, p_list_id uuid, p_details jsonb)
returns void language sql security definer set search_path = public as $$
  insert into public.audit_events (actor_id, actor_name, action, entity, entity_id, list_id, details)
  values (auth.uid(), public.actor_name(), p_action, p_entity, p_entity_id, p_list_id, coalesce(p_details, '{}'::jsonb))
$$;

-- Profil créé automatiquement pour chaque compte Auth.
-- Un compte qui ne vient pas de la fonction admin-users reste INACTIF (inscription libre inutile).
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, role, active)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'full_name', ''), split_part(coalesce(new.email, 'utilisateur'), '@', 1)),
    'employee',
    coalesce((new.raw_app_meta_data->>'provisioned') = 'true', false)
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- Sécurité par lignes (RLS)
-- ---------------------------------------------------------------------
alter table public.profiles      enable row level security;
alter table public.list_types    enable row level security;
alter table public.lists         enable row level security;
alter table public.list_items    enable row level security;
alter table public.item_results  enable row level security;
alter table public.reports       enable row level security;
alter table public.audit_events  enable row level security;

drop policy if exists profiles_read   on public.profiles;
drop policy if exists profiles_admin  on public.profiles;
create policy profiles_read  on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_manager());
create policy profiles_admin on public.profiles for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists types_read  on public.list_types;
drop policy if exists types_write on public.list_types;
create policy types_read  on public.list_types for select to authenticated using (public.app_role() is not null);
create policy types_write on public.list_types for all to authenticated
  using (public.is_manager()) with check (public.is_manager());

drop policy if exists lists_read  on public.lists;
drop policy if exists lists_write on public.lists;
create policy lists_read on public.lists for select to authenticated
  using (public.is_manager() or (public.app_role() is not null and status = 'published' and work_date >= current_date - 7));
create policy lists_write on public.lists for all to authenticated
  using (public.is_manager()) with check (public.is_manager());

drop policy if exists items_read  on public.list_items;
drop policy if exists items_write on public.list_items;
create policy items_read on public.list_items for select to authenticated
  using (exists (select 1 from public.lists l where l.id = list_id));
create policy items_write on public.list_items for all to authenticated
  using (public.is_manager()) with check (public.is_manager());

-- Résultats : lecture seule. Écriture uniquement via les fonctions ci-dessous.
drop policy if exists results_read on public.item_results;
create policy results_read on public.item_results for select to authenticated
  using (exists (select 1 from public.list_items i join public.lists l on l.id = i.list_id where i.id = item_id));

drop policy if exists reports_read on public.reports;
create policy reports_read on public.reports for select to authenticated
  using (public.is_manager() or reported_by = auth.uid());

drop policy if exists audit_read on public.audit_events;
create policy audit_read on public.audit_events for select to authenticated using (public.is_manager());

-- ---------------------------------------------------------------------
-- Fonction centrale : l'employé envoie la quantité réellement préparée
-- ---------------------------------------------------------------------
create or replace function public.submit_item_result(
  p_item_id uuid, p_prepared numeric, p_reason text default null, p_comment text default null
) returns public.item_results
language plpgsql security definer set search_path = public as $$
declare
  v_item     public.list_items;
  v_list     public.lists;
  v_res      public.item_results;
  v_reason   text := nullif(btrim(coalesce(p_reason, '')), '');
  v_comment  text := nullif(btrim(coalesce(p_comment, '')), '');
  v_name     text := public.actor_name();
  v_diff     numeric;
  v_status   text;
  v_missing  numeric := 0;
  v_surplus  numeric := 0;
  v_reasons  text[] := array['Rupture de stock','Quantité insuffisante à la livraison','Problème de production','Manque de temps','Problème matériel','Autre raison'];
begin
  if public.app_role() is null then raise exception 'Compte inactif ou non autorisé.'; end if;
  if p_prepared is null or p_prepared < 0 then raise exception 'Saisis une quantité valide (nombre positif).'; end if;

  select * into v_item from public.list_items where id = p_item_id;
  if not found then raise exception 'Ligne introuvable.'; end if;
  select * into v_list from public.lists where id = v_item.list_id;
  if v_list.status <> 'published' then raise exception 'Cette liste n’est pas ouverte à la saisie.'; end if;

  -- Verrou : empêche deux validations simultanées de la même ligne.
  insert into public.item_results (item_id) values (p_item_id) on conflict (item_id) do nothing;
  select * into v_res from public.item_results where item_id = p_item_id for update;
  if v_res.status in ('done','gap_accepted') then
    raise exception 'Cette ligne est déjà validée. Seul un manager peut la rouvrir.';
  end if;

  v_diff := round(p_prepared - v_item.requested_qty, 3);

  if v_diff < 0 then
    if v_reason is null then raise exception 'Choisis une raison pour expliquer la quantité manquante.'; end if;
    if not (v_reason = any (v_reasons)) then raise exception 'Cette raison n’existe pas.'; end if;
    if v_reason = 'Autre raison' and coalesce(length(v_comment), 0) < 3 then
      raise exception 'Explique la raison dans le commentaire.';
    end if;
    v_status := 'partial';
    v_missing := -v_diff;
  else
    if v_diff > 0 then
      if v_list.surplus_policy = 'justify' and coalesce(length(v_comment), 0) < 3 then
        raise exception 'Ajoute un commentaire : la quantité préparée dépasse la demande.';
      end if;
      v_surplus := v_diff;
    end if;
    v_status := 'done';
  end if;

  update public.item_results set
    status = v_status,
    prepared_qty = p_prepared,
    missing_qty = v_missing,
    surplus_qty = v_surplus,
    comment = v_comment,
    updated_by = auth.uid(), updated_by_name = v_name, updated_at = now(),
    completed_by = case when v_status = 'done' then auth.uid() else null end,
    completed_by_name = case when v_status = 'done' then v_name else null end,
    completed_at = case when v_status = 'done' then now() else null end
  where item_id = p_item_id
  returning * into v_res;

  if v_status = 'partial' then
    -- Un seul signalement ouvert par ligne : on le met à jour si l'employé renvoie une nouvelle quantité.
    update public.reports set
      prepared_qty = p_prepared, missing_qty = v_missing, reason = v_reason, comment = v_comment,
      reported_by = auth.uid(), reported_by_name = v_name, reported_at = now()
    where item_id = p_item_id and status = 'open';
    if not found then
      insert into public.reports (item_id, list_id, requested_qty, prepared_qty, missing_qty, reason, comment, reported_by, reported_by_name)
      values (p_item_id, v_list.id, v_item.requested_qty, p_prepared, v_missing, v_reason, v_comment, auth.uid(), v_name);
    end if;
    perform public.log_event('validation_partielle', 'list_item', p_item_id, v_list.id,
      jsonb_build_object('product', v_item.product, 'unit', v_item.unit, 'requested', v_item.requested_qty,
                         'prepared', p_prepared, 'missing', v_missing, 'reason', v_reason, 'comment', v_comment));
  else
    update public.reports set status = 'resolved', decision = 'completed',
      decision_note = 'Production complétée par l’employé.', decided_at = now()
    where item_id = p_item_id and status = 'open';
    perform public.log_event(case when v_surplus > 0 then 'validation_surplus' else 'validation' end, 'list_item', p_item_id, v_list.id,
      jsonb_build_object('product', v_item.product, 'unit', v_item.unit, 'requested', v_item.requested_qty,
                         'prepared', p_prepared, 'surplus', v_surplus, 'comment', v_comment));
  end if;
  return v_res;
end $$;

-- L'employé indique qu'il a commencé.
create or replace function public.start_item(p_item_id uuid) returns public.item_results
language plpgsql security definer set search_path = public as $$
declare v_item public.list_items; v_list public.lists; v_res public.item_results;
begin
  if public.app_role() is null then raise exception 'Compte inactif ou non autorisé.'; end if;
  select * into v_item from public.list_items where id = p_item_id;
  if not found then raise exception 'Ligne introuvable.'; end if;
  select * into v_list from public.lists where id = v_item.list_id;
  if v_list.status <> 'published' then raise exception 'Cette liste n’est pas ouverte à la saisie.'; end if;
  insert into public.item_results (item_id) values (p_item_id) on conflict (item_id) do nothing;
  select * into v_res from public.item_results where item_id = p_item_id for update;
  if v_res.status = 'todo' then
    update public.item_results set status = 'in_progress', updated_by = auth.uid(), updated_by_name = public.actor_name(), updated_at = now()
    where item_id = p_item_id returning * into v_res;
    perform public.log_event('demarrage', 'list_item', p_item_id, v_list.id, jsonb_build_object('product', v_item.product));
  end if;
  return v_res;
end $$;

-- ---------------------------------------------------------------------
-- Décisions du management
-- ---------------------------------------------------------------------
create or replace function public.decide_report(p_report_id uuid, p_decision text, p_note text default null)
returns public.reports
language plpgsql security definer set search_path = public as $$
declare
  v_rep public.reports; v_note text := nullif(btrim(coalesce(p_note, '')), '');
  v_item_status text; v_resolves boolean; v_product text;
begin
  if not public.is_manager() then raise exception 'Réservé au management.'; end if;
  select * into v_rep from public.reports where id = p_report_id for update;
  if not found then raise exception 'Signalement introuvable.'; end if;
  if v_rep.status <> 'open' then raise exception 'Ce signalement est déjà clos.'; end if;

  case p_decision
    when 'complete'    then v_item_status := 'to_fix';       v_resolves := false;
    when 'recheck'     then v_item_status := 'to_fix';       v_resolves := false;
    when 'instruction' then v_item_status := 'partial';      v_resolves := false;
    when 'accept'      then v_item_status := 'gap_accepted'; v_resolves := true;
    when 'close'       then v_item_status := 'gap_accepted'; v_resolves := true;
    else raise exception 'Décision inconnue.';
  end case;
  if p_decision in ('instruction','accept','close') and coalesce(length(v_note), 0) < 3 then
    raise exception 'Ajoute une justification ou une consigne pour cette décision.';
  end if;

  update public.reports set
    decision = p_decision, decision_note = v_note, decided_by = auth.uid(), decided_by_name = public.actor_name(),
    decided_at = now(), status = case when v_resolves then 'resolved' else 'open' end
  where id = p_report_id returning * into v_rep;

  update public.item_results set
    status = v_item_status,
    manager_instruction = coalesce(v_note, manager_instruction),
    updated_by = auth.uid(), updated_by_name = public.actor_name(), updated_at = now()
  where item_id = v_rep.item_id;

  select product into v_product from public.list_items where id = v_rep.item_id;
  perform public.log_event('decision_' || p_decision, 'report', v_rep.id, v_rep.list_id,
    jsonb_build_object('product', v_product, 'note', v_note, 'missing', v_rep.missing_qty, 'reason', v_rep.reason));
  return v_rep;
end $$;

-- Rouvrir une ligne déjà validée (manager).
create or replace function public.reopen_item(p_item_id uuid, p_note text default null)
returns public.item_results
language plpgsql security definer set search_path = public as $$
declare v_res public.item_results; v_item public.list_items; v_note text := nullif(btrim(coalesce(p_note, '')), '');
begin
  if not public.is_manager() then raise exception 'Réservé au management.'; end if;
  select * into v_item from public.list_items where id = p_item_id;
  if not found then raise exception 'Ligne introuvable.'; end if;
  insert into public.item_results (item_id) values (p_item_id) on conflict (item_id) do nothing;
  update public.item_results set status = 'to_fix', manager_instruction = coalesce(v_note, manager_instruction),
    completed_by = null, completed_by_name = null, completed_at = null,
    updated_by = auth.uid(), updated_by_name = public.actor_name(), updated_at = now()
  where item_id = p_item_id returning * into v_res;
  perform public.log_event('reouverture', 'list_item', p_item_id, v_item.list_id,
    jsonb_build_object('product', v_item.product, 'note', v_note));
  return v_res;
end $$;

-- Publier, dépublier (seulement si personne n'a commencé), clôturer.
create or replace function public.set_list_status(p_list_id uuid, p_status text)
returns public.lists
language plpgsql security definer set search_path = public as $$
declare v_list public.lists; v_count int;
begin
  if not public.is_manager() then raise exception 'Réservé au management.'; end if;
  if p_status not in ('draft','published','closed') then raise exception 'Statut inconnu.'; end if;
  select * into v_list from public.lists where id = p_list_id for update;
  if not found then raise exception 'Liste introuvable.'; end if;

  if p_status = 'published' then
    select count(*) into v_count from public.list_items where list_id = p_list_id;
    if v_count = 0 then raise exception 'Ajoute au moins un produit avant de publier.'; end if;
  end if;
  if p_status = 'draft' then
    select count(*) into v_count from public.item_results r join public.list_items i on i.id = r.item_id
      where i.list_id = p_list_id and r.status <> 'todo';
    if v_count > 0 then raise exception 'Du travail est déjà enregistré : impossible de repasser en brouillon. Clôture la liste à la place.'; end if;
  end if;

  update public.lists set status = p_status, updated_at = now(),
    published_at = case when p_status = 'published' and published_at is null then now() else published_at end
  where id = p_list_id returning * into v_list;
  perform public.log_event(case p_status when 'published' then 'publication' when 'closed' then 'cloture' else 'depublication' end,
    'list', p_list_id, p_list_id, jsonb_build_object('name', v_list.name));
  return v_list;
end $$;

-- Dupliquer une liste (copie en brouillon, sans aucun résultat).
create or replace function public.duplicate_list(p_list_id uuid, p_date date)
returns uuid
language plpgsql security definer set search_path = public as $$
declare v_new uuid; v_src public.lists;
begin
  if not public.is_manager() then raise exception 'Réservé au management.'; end if;
  select * into v_src from public.lists where id = p_list_id;
  if not found then raise exception 'Liste introuvable.'; end if;
  insert into public.lists (name, type_id, work_date, period, due_time, instructions, surplus_policy, status, created_by)
  values (v_src.name, v_src.type_id, coalesce(p_date, current_date), v_src.period, v_src.due_time, v_src.instructions, v_src.surplus_policy, 'draft', auth.uid())
  returning id into v_new;
  insert into public.list_items (list_id, product, requested_qty, unit, comment, sort_order)
    select v_new, product, requested_qty, unit, comment, sort_order from public.list_items where list_id = p_list_id;
  perform public.log_event('duplication', 'list', v_new, v_new, jsonb_build_object('source', p_list_id, 'name', v_src.name));
  return v_new;
end $$;

-- ---------------------------------------------------------------------
-- Historique automatique des modifications faites par le management
-- ---------------------------------------------------------------------
create or replace function public.audit_list_items() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_list_id uuid := coalesce(new.list_id, old.list_id); v_status text; v_row public.list_items := coalesce(new, old);
begin
  select status into v_status from public.lists where id = v_list_id;
  if v_status = 'published' then
    perform public.log_event('modification_apres_publication', 'list_item', v_row.id, v_list_id,
      jsonb_build_object('operation', tg_op, 'product', v_row.product,
        'old_qty', case when tg_op <> 'INSERT' then old.requested_qty end,
        'new_qty', case when tg_op <> 'DELETE' then new.requested_qty end,
        'unit', v_row.unit));
  end if;
  return coalesce(new, old);
end $$;
drop trigger if exists audit_list_items_trg on public.list_items;
create trigger audit_list_items_trg after insert or update or delete on public.list_items
  for each row execute function public.audit_list_items();

create or replace function public.audit_lists() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    perform public.log_event('creation_liste', 'list', new.id, new.id, jsonb_build_object('name', new.name));
  elsif tg_op = 'UPDATE' and new.status = 'published' and old.status = 'published'
        and (new.name, new.work_date, new.instructions, new.due_time, new.surplus_policy)
            is distinct from (old.name, old.work_date, old.instructions, old.due_time, old.surplus_policy) then
    perform public.log_event('modification_apres_publication', 'list', new.id, new.id, jsonb_build_object('name', new.name));
  end if;
  return new;
end $$;
drop trigger if exists audit_lists_trg on public.lists;
create trigger audit_lists_trg after insert or update on public.lists
  for each row execute function public.audit_lists();

create or replace function public.audit_profiles() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (new.role, new.active, new.full_name) is distinct from (old.role, old.active, old.full_name) then
    perform public.log_event('compte_modifie', 'profile', new.id, null,
      jsonb_build_object('name', new.full_name, 'role', new.role, 'active', new.active, 'old_role', old.role, 'old_active', old.active));
  end if;
  return new;
end $$;
drop trigger if exists audit_profiles_trg on public.profiles;
create trigger audit_profiles_trg after update on public.profiles
  for each row execute function public.audit_profiles();

-- ---------------------------------------------------------------------
-- Droits d'exécution : uniquement les utilisateurs connectés
-- ---------------------------------------------------------------------
revoke all on function public.submit_item_result(uuid, numeric, text, text) from public, anon;
revoke all on function public.start_item(uuid) from public, anon;
revoke all on function public.decide_report(uuid, text, text) from public, anon;
revoke all on function public.reopen_item(uuid, text) from public, anon;
revoke all on function public.set_list_status(uuid, text) from public, anon;
revoke all on function public.duplicate_list(uuid, date) from public, anon;
grant execute on function public.submit_item_result(uuid, numeric, text, text) to authenticated;
grant execute on function public.start_item(uuid) to authenticated;
grant execute on function public.decide_report(uuid, text, text) to authenticated;
grant execute on function public.reopen_item(uuid, text) to authenticated;
grant execute on function public.set_list_status(uuid, text) to authenticated;
grant execute on function public.duplicate_list(uuid, date) to authenticated;
revoke all on function public.log_event(text, text, uuid, uuid, jsonb) from public, anon, authenticated;

-- ---------------------------------------------------------------------
-- Temps réel : les écrans se mettent à jour sans recharger la page
-- ---------------------------------------------------------------------
do $$
declare t text;
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['lists','list_items','item_results','reports'] loop
      if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
        execute format('alter publication supabase_realtime add table public.%I', t);
      end if;
    end loop;
  end if;
end $$;

-- ---------------------------------------------------------------------
-- Types de listes de départ (modifiables ensuite dans l'application)
-- ---------------------------------------------------------------------
insert into public.list_types (name, color, sort_order)
select v.name, v.color, v.ord from (values
  ('Inventaire',                '#1F63B5', 0),
  ('Production du matin',       '#0B7A75', 1),
  ('Production de l’après-midi', '#B96A00', 2),
  ('Point de production',       '#6B45A8', 3),
  ('Préparation avant service', '#C0322B', 4),
  ('Contrôle des stocks',       '#4C6A00', 5),
  ('Nettoyage',                 '#5B6B76', 6),
  ('Contrôle de fin de service','#0B3C5D', 7)
) as v(name, color, ord)
where not exists (select 1 from public.list_types);

-- =====================================================================
-- Premier administrateur : après avoir créé votre compte dans
-- Authentication → Users, exécutez (en remplaçant l'e-mail) :
--
--   update public.profiles set role = 'admin', active = true
--   where id = (select id from auth.users where email = 'vous@exemple.fr');
-- =====================================================================
