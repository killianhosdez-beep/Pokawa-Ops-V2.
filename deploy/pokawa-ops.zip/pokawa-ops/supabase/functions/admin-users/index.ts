// Fonction Edge « admin-users » : création de comptes et réinitialisation de mot de passe.
// Seul un administrateur connecté peut l'appeler. Elle utilise la clé service_role,
// qui reste côté Supabase (jamais dans le navigateur).
//
// Déploiement : supabase functions deploy admin-users
// (SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY sont fournis automatiquement.)
//
// Corps attendu (JSON) :
//   { "action": "create", "username": "emma", "full_name": "Emma Durand", "role": "employee", "password": "..." }
//   { "action": "reset_password", "user_id": "uuid", "password": "..." }
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const AUTH_DOMAIN = Deno.env.get('AUTH_DOMAIN') ?? 'pokawa-ops.local'; // doit correspondre à js/config.js
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ error: 'Méthode non autorisée.' }, 405);

  const url = Deno.env.get('SUPABASE_URL')!;
  const authHeader = req.headers.get('Authorization') ?? '';

  // 1. Qui appelle ? (jeton de l'utilisateur connecté)
  const asCaller = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: authHeader } } });
  const { data: caller, error: callerErr } = await asCaller.auth.getUser();
  if (callerErr || !caller?.user) return json({ error: 'Connexion requise.' }, 401);

  // 2. Est-il administrateur actif ?
  const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false } });
  const { data: profile } = await admin.from('profiles').select('role, active').eq('id', caller.user.id).single();
  if (!profile || profile.role !== 'admin' || !profile.active) return json({ error: 'Réservé aux administrateurs.' }, 403);

  let body: Record<string, string>;
  try { body = await req.json(); } catch { return json({ error: 'Requête invalide.' }, 400); }

  const password = String(body.password ?? '');
  if (password.length < 8) return json({ error: 'Le mot de passe doit contenir au moins 8 caractères.' }, 400);

  if (body.action === 'create') {
    const username = String(body.username ?? '').trim().toLowerCase();
    const fullName = String(body.full_name ?? '').trim();
    const role = ['employee', 'manager', 'admin'].includes(body.role) ? body.role : 'employee';
    if (!/^[a-z0-9._-]{2,32}$/.test(username)) return json({ error: 'Identifiant : 2 à 32 caractères (lettres, chiffres, . _ -).' }, 400);
    if (fullName.length < 2) return json({ error: 'Indique le nom de la personne.' }, 400);

    const email = username.includes('@') ? username : `${username}@${AUTH_DOMAIN}`;
    const { data, error } = await admin.auth.admin.createUser({
      email, password, email_confirm: true,
      user_metadata: { full_name: fullName },
      app_metadata: { provisioned: 'true' }, // sans cela le profil reste inactif (voir schema.sql)
    });
    if (error) return json({ error: error.message.includes('already') ? 'Cet identifiant existe déjà.' : error.message }, 400);

    const { error: upErr } = await admin.from('profiles')
      .update({ role, full_name: fullName, active: true }).eq('id', data.user!.id);
    if (upErr) return json({ error: upErr.message }, 500);
    await admin.from('audit_events').insert({
      actor_id: caller.user.id, action: 'compte_cree', entity: 'profile', entity_id: data.user!.id,
      actor_name: caller.user.email, details: { name: fullName, role },
    });
    return json({ ok: true, user_id: data.user!.id });
  }

  if (body.action === 'reset_password') {
    const { error } = await admin.auth.admin.updateUserById(String(body.user_id), { password });
    if (error) return json({ error: error.message }, 400);
    await admin.from('audit_events').insert({
      actor_id: caller.user.id, action: 'mot_de_passe_reinitialise', entity: 'profile',
      entity_id: String(body.user_id), actor_name: caller.user.email, details: {},
    });
    return json({ ok: true });
  }

  return json({ error: 'Action inconnue.' }, 400);
});
