#!/usr/bin/env bash
# Crée un Postgres jetable, y exécute supabase/schema.sql + tests/schema_test.sql, puis le supprime.
# Nécessite PostgreSQL installé (testé avec la version 16).
set -euo pipefail
cd "$(dirname "$0")/.."
PGBIN=$(ls -d /usr/lib/postgresql/*/bin | sort -V | tail -1)
DIR=$(mktemp -d); chmod 755 "$DIR"; chown postgres "$DIR" 2>/dev/null || true
RUN() { if [ "$(id -u)" = 0 ]; then su postgres -c "$*"; else bash -c "$*"; fi; }
PORT=54329
RUN "$PGBIN/initdb -D $DIR/data -A trust >/dev/null"
RUN "$PGBIN/pg_ctl -D $DIR/data -o '-p $PORT -k $DIR' -l $DIR/log -w start >/dev/null"
trap 'RUN "$PGBIN/pg_ctl -D $DIR/data -m immediate stop >/dev/null" || true; rm -rf "$DIR"' EXIT
chmod -R a+rX "$(pwd)" 2>/dev/null || true
RUN "$PGBIN/psql -h $DIR -p $PORT -d postgres -X -q -f $(pwd)/tests/schema_test.sql" 2>&1 | grep -v -E '^(NOTICE|psql:.*NOTICE)'
