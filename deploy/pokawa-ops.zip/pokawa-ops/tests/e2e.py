"""Test de bout en bout dans un vrai navigateur (Chromium via Playwright).
Lancer : python3 tests/e2e.py   (depuis la racine du projet)
Scénario du cahier des charges : manager crée/publie, employé saisit 12 puis 9 kg, etc.
"""
import http.server, threading, functools, sys, os, re
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOTS = os.environ.get("SHOTS", "/tmp/pokawa-shots")
os.makedirs(SHOTS, exist_ok=True)

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k):
        pass
handler = functools.partial(Quiet, directory=ROOT)
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
URL = f"http://127.0.0.1:{srv.server_address[1]}/index.html"
threading.Thread(target=srv.serve_forever, daemon=True).start()

results = []
def check(name, cond, detail=""):
    results.append((bool(cond), name, detail))
    print(("OK    " if cond else "ECHEC ") + name + (f"  [{detail}]" if detail and not cond else ""))

def login(page, username, password):
    page.goto(URL)
    page.fill("input[name=username]", username)
    page.fill("input[name=password]", password)
    page.click("button[type=submit]")
    page.wait_for_selector(".topbar")

with sync_playwright() as p:
    browser = p.chromium.launch()
    errors = []

    def new_ctx(**kw):
        ctx = browser.new_context(locale="fr-FR", timezone_id="Europe/Paris", **kw)
        return ctx

    def watch(page):
        page.on("pageerror", lambda e: errors.append("pageerror: " + str(e)))
        page.on("console", lambda m: errors.append("console: " + m.text) if m.type == "error" else None)

    # --- contexte partagé : même localStorage pour manager et employé (comme deux onglets d'un même appareil de démo)
    ctx = new_ctx(viewport={"width": 1200, "height": 800})
    mgr = ctx.new_page(); watch(mgr)

    # ---------- 1. mauvaise connexion ----------
    mgr.goto(URL)
    mgr.fill("input[name=username]", "manager"); mgr.fill("input[name=password]", "faux")
    mgr.click("button[type=submit]")
    check("mauvais mot de passe : message clair", "incorrect" in mgr.inner_text("#loginError"))

    # ---------- 2. manager : création d'une liste ----------
    login(mgr, "manager", "manager1234")
    check("manager arrive sur le tableau de bord", "Tableau de bord" in mgr.inner_text("#view"))
    mgr.screenshot(path=f"{SHOTS}/01-manager-dashboard-desktop.png")

    mgr.goto(URL + "#/lists"); mgr.click("text=Nouvelle liste >> nth=0")
    mgr.wait_for_selector("#listForm")
    # type : on choisit « Production du matin » (dans la liste), pour vérifier que le choix de type n'est pas bloqué
    types_available = mgr.eval_on_selector_all("select[data-l=type_id] option", "o => o.map(x => x.textContent)")
    check("sélecteur de type : les 8 types sont proposés", len(types_available) == 8, str(types_available))
    mgr.select_option("select[data-l=type_id]", label="Inventaire")
    mgr.select_option("select[data-l=type_id]", label="Production de l’après-midi")
    mgr.select_option("select[data-l=type_id]", label="Production du matin")
    mgr.fill("input[data-l=name]", "Test cahier des charges")
    rows = mgr.locator(".item-edit")
    rows.nth(0).locator("[data-f=product]").fill("Riz")
    rows.nth(0).locator("[data-f=requested_qty]").fill("12")
    rows.nth(0).locator("[data-f=unit]").fill("kg")
    mgr.click("#addItem")
    rows = mgr.locator(".item-edit")
    rows.nth(1).locator("[data-f=product]").fill("Guacamole")
    rows.nth(1).locator("[data-f=requested_qty]").fill("6")
    rows.nth(1).locator("[data-f=unit]").fill("bac")
    mgr.screenshot(path=f"{SHOTS}/02-manager-editor-desktop.png")

    # validation : ligne sans quantité refusée
    mgr.click("#addItem")
    mgr.locator(".item-edit").nth(2).locator("[data-f=product]").fill("Sauce")
    mgr.click("[data-after=save]")
    err = mgr.inner_text("#editError")
    check("quantité manquante : message précis", "quantité" in err.lower(), err)
    mgr.locator(".item-edit").nth(2).locator("[data-del]").click()

    # enregistrer en brouillon
    mgr.click("[data-after=save]")
    mgr.wait_for_selector("text=Brouillon")
    check("liste enregistrée en brouillon", "Brouillon" in mgr.inner_text("#view"))
    list_url = mgr.url

    # ---------- 3. brouillon invisible côté employé ----------
    emp = ctx.new_page(); watch(emp)
    login(emp, "emma", "emma1234")
    check("brouillon invisible pour l'employé", "Test cahier des charges" not in emp.inner_text("#view"))
    check("employé n'a pas la navigation management", "Mes signalements" in emp.inner_text(".nav") and "Équipe" not in emp.inner_text(".nav") and "Réglages" not in emp.inner_text(".nav"))

    # ---------- 4. publication ----------
    mgr.click("text=Publier >> nth=0")
    mgr.click("dialog[open] button[data-v='1']")
    mgr.wait_for_selector("text=Publiée")
    check("liste publiée", "Publiée" in mgr.inner_text("#view"))

    emp.reload()
    emp.wait_for_selector(".view")
    check("liste publiée visible côté employé", "Test cahier des charges" in emp.inner_text("#view"))

    # ---------- 5. employé : test 1 — 12 kg valide ----------
    emp.click("text=Test cahier des charges")
    emp.click("text=Riz")
    emp.wait_for_selector("#qty")
    check("employé voit les 12 kg demandés", "12" in emp.inner_text(".big-qty"))
    check("bouton Valider désactivé tant que rien n'est saisi", emp.is_disabled("#submitBtn"))
    emp.fill("#qty", "12")
    check("12 / 12 : quantité complète", "Quantité complète" in emp.inner_text("#verdict"))
    check("12 / 12 : validation autorisée", not emp.is_disabled("#submitBtn"))
    check("12 / 12 : pas de demande de raison", not emp.is_visible("#reasonBlock"))
    emp.click("#submitBtn")
    emp.wait_for_selector("text=Riz validé")
    check("Riz validé", "Terminé" in emp.inner_text("#view"))

    # ---------- 6. employé : test 2/3/4 — 9 sur 12 ----------
    # on utilise le guacamole (6 demandés) -> 4 préparés ; puis on teste exactement 12/9 sur une 2e liste plus bas
    emp.click("text=Guacamole")
    emp.wait_for_selector("#qty")
    emp.fill("#qty", "4")
    verdict = emp.inner_text("#verdict")
    check("4 / 6 : alerte quantité insuffisante", "Quantité insuffisante" in verdict and "Manque 2" in verdict, verdict)
    check("4 / 6 : raison obligatoire affichée", emp.is_visible("#reasonBlock"))
    check("4 / 6 : validation bloquée sans raison", emp.is_disabled("#submitBtn"))
    emp.wait_for_timeout(500)
    emp.screenshot(path=f"{SHOTS}/03-employee-shortfall-desktop.png")
    emp.click("[data-reason='Autre raison']")
    check("« Autre raison » sans commentaire : toujours bloqué", emp.is_disabled("#submitBtn"))
    emp.fill("#comment", "Four en panne")
    check("« Autre raison » + commentaire : débloqué", not emp.is_disabled("#submitBtn"))
    emp.click("[data-reason='Rupture de stock']")
    emp.fill("#comment", "")
    check("« Rupture de stock » seule : débloqué", not emp.is_disabled("#submitBtn"))
    emp.click("#submitBtn")
    emp.wait_for_selector("text=Écart signalé")
    check("signalement transmis", "Production partielle" in emp.inner_text("#view"))

    # saisie non numérique
    emp.click("text=Guacamole")
    # ligne partielle : on peut renvoyer, on teste une saisie invalide
    emp.wait_for_selector("#qty")
    emp.fill("#qty", "abc")
    check("saisie « abc » : refusée", emp.is_disabled("#submitBtn"))
    emp.fill("#qty", "-3")
    check("saisie négative : refusée", emp.is_disabled("#submitBtn"))
    emp.fill("#qty", "5,5")
    check("virgule française acceptée (5,5 sur 6)", "Manque 0,5" in emp.inner_text("#verdict"), emp.inner_text("#verdict"))
    emp.click("[data-act=closeSheet]")

    # ---------- 7. manager voit et décide ----------
    mgr.goto(URL + "#/reports")
    mgr.wait_for_selector("text=Signalements")
    check("manager : badge signalement dans la navigation", mgr.locator(".nav .badge").count() == 1)
    txt = mgr.inner_text("#view")
    check("manager voit produit, manquant, motif, auteur", all(s in txt for s in ["Guacamole", "Rupture de stock", "Emma Leroy"]), txt[:300])
    mgr.screenshot(path=f"{SHOTS}/04-manager-reports-desktop.png")
    mgr.click("button[data-act=openDecision] >> nth=0")
    mgr.wait_for_selector("form[data-form=decide]")
    mgr.check("input[value=accept]")
    mgr.click("dialog[open] button[type=submit]")
    check("accepter l'écart sans justification : refusé", "justification" in mgr.inner_text("#decideError").lower())
    mgr.fill("textarea[name=note]", "Livraison en retard, validé avec le gérant")
    mgr.click("dialog[open] button[type=submit]")
    mgr.wait_for_selector("text=Décision enregistrée")
    mgr.goto(URL + "#/" + list_url.split("#/")[1])
    mgr.wait_for_selector("text=Écart accepté")
    check("écart accepté ≠ terminé (statut distinct)", "Écart accepté par le management" in mgr.inner_text("#view"))

    # employé ne peut plus revalider
    emp.reload(); emp.wait_for_selector(".view")
    emp.click("text=Test cahier des charges"); emp.click("text=Guacamole")
    emp.wait_for_selector(".sheet")
    check("employé : ligne validée non modifiable", emp.locator("#qty").count() == 0)
    emp.click("[data-act=closeSheet]")

    # ---------- 8. test spécifique 12 kg / 9 kg (cahier des charges §15) ----------
    mgr.goto(URL + "#/lists"); mgr.click("text=Nouvelle liste >> nth=0"); mgr.wait_for_selector("#listForm")
    mgr.fill("input[data-l=name]", "Test 12 kg")
    mgr.select_option("select[data-l=type_id]", label="Production du matin")
    r0 = mgr.locator(".item-edit").nth(0)
    r0.locator("[data-f=product]").fill("Riz"); r0.locator("[data-f=requested_qty]").fill("12"); r0.locator("[data-f=unit]").fill("kg")
    mgr.click("[data-after=publish]"); mgr.click("dialog[open] button[data-v='1']")
    mgr.wait_for_selector("text=Publiée")
    emp.goto(URL + "#/today"); emp.reload(); emp.wait_for_selector(".view")
    emp.click("text=Test 12 kg"); emp.click("text=Riz"); emp.wait_for_selector("#qty")
    emp.fill("#qty", "9")
    v = emp.inner_text("#verdict")
    check("12 kg demandés / 9 préparés : « Manque 3 kg »", "Manque 3" in v and "kg" in v, v)
    check("9 / 12 : validation normale impossible", emp.is_disabled("#submitBtn"))
    emp.click("[data-reason='Rupture de stock']")
    emp.click("#submitBtn"); emp.wait_for_selector("text=Écart signalé")
    mgr.goto(URL + "#/reports"); mgr.wait_for_selector("text=Signalements")
    check("manager retrouve motif + 3 kg manquants", "Rupture de stock" in mgr.inner_text("#view") and "3 kg" in mgr.inner_text("#view").replace(" ", " "))

    # ---------- 9. historique ----------
    mgr.goto(URL + "#/history"); mgr.wait_for_selector("text=Historique")
    mgr.click("[data-t=journal]")
    j = mgr.inner_text("#view")
    check("journal : validation, écart, décision tracés", all(s in j for s in ["production partielle", "Décision", "Emma Leroy"]), j[:400])
    mgr.fill("input[name=employee]", "karim"); mgr.click("text=Rechercher")
    check("recherche par employé : filtre appliqué", "Emma Leroy" not in mgr.inner_text("#view"))
    mgr.click("text=Réinitialiser")

    # ---------- 10. sécurité côté interface ----------
    emp.goto(URL + "#/settings"); emp.wait_for_selector(".view")
    check("employé tapant #/settings : reste sur l'écran employé", "Types de listes" not in emp.inner_text("#view"))
    emp.goto(URL + "#/team"); emp.wait_for_selector(".view")
    check("employé tapant #/team : refusé", "Nouveau compte" not in emp.inner_text("#view"))
    # appel direct au backend avec la session employé
    res = emp.evaluate("""async () => {
      const out = {};
      for (const [k, fn] of Object.entries({
        publier: () => LocalBackend.setListStatus(Object.keys(App.S.idx.list)[0], 'closed'),
        creerCompte: () => LocalBackend.createAccount({username:'pirate', full_name:'Pirate', role:'admin', password:'12345678'}),
        decider: () => LocalBackend.decideReport('x', 'accept', 'ok ok'),
      })) { try { await fn(); out[k] = 'ACCEPTÉ'; } catch (e) { out[k] = e.message; } }
      return out; }""")
    check("backend démo : l'employé ne peut ni publier, ni créer de compte, ni décider",
          all(v != "ACCEPTÉ" for v in res.values()), str(res))

    # ---------- 11. compte désactivé ----------
    adm = ctx.new_page(); watch(adm)
    login(adm, "admin", "admin1234")
    adm.goto(URL + "#/team"); adm.wait_for_selector("text=Équipe")
    adm.click("text=Karim Benali >> xpath=ancestor::div[contains(@class,'panel')] >> text=Désactiver")
    adm.click("dialog[open] button[data-v='1']")
    adm.wait_for_selector("text=Compte désactivé.")
    kp = ctx.new_page(); watch(kp)
    kp.goto(URL); kp.fill("input[name=username]", "karim"); kp.fill("input[name=password]", "karim1234"); kp.click("button[type=submit]")
    kp.wait_for_selector("#loginError:not(:empty)")
    check("compte désactivé : connexion refusée avec message", "désactivé" in kp.inner_text("#loginError"))

    # création d'un compte, connexion
    adm.click("text=Nouveau compte >> nth=0"); adm.wait_for_selector("form[data-form=newAccount]")
    adm.fill("input[name=full_name]", "Léa Nouvelle"); adm.fill("input[name=username]", "lea"); adm.fill("input[name=password]", "motdepasse1")
    adm.click("form[data-form=newAccount] button[type=submit]")
    adm.wait_for_selector("text=Léa Nouvelle")
    lp = ctx.new_page(); watch(lp); login(lp, "lea", "motdepasse1")
    check("nouveau compte employé : connexion OK", "Aujourd’hui" in lp.inner_text("#view"))

    # ---------- 12. types de listes personnalisés ----------
    mgr.goto(URL + "#/settings"); mgr.wait_for_selector("text=Types de listes")
    last = mgr.locator("form[data-form=saveType]").last
    last.locator("input[name=name]").fill("Ouverture de salle"); last.locator("button[type=submit]").click()
    mgr.wait_for_selector("text=Type enregistré")
    mgr.goto(URL + "#/lists"); mgr.click("text=Nouvelle liste >> nth=0"); mgr.wait_for_selector("#listForm")
    check("nouveau type créé sans toucher au code", "Ouverture de salle" in mgr.eval_on_selector_all("select[data-l=type_id] option", "o => o.map(x => x.textContent)"))
    mgr.click("[data-act=closeSheet]")

    # ---------- 13. persistance après actualisation ----------
    emp.goto(URL + "#/today"); emp.reload(); emp.wait_for_selector(".view")
    check("après actualisation : session et données conservées", "Test cahier des charges" in emp.inner_text("#view") or "Test 12 kg" in emp.inner_text("#view"))

    ctx.close()

    # ---------- 14. mobile ----------
    iphone = p.devices["iPhone 13"]
    mctx = browser.new_context(**iphone, locale="fr-FR", timezone_id="Europe/Paris")
    m = mctx.new_page(); watch(m)
    login(m, "emma", "emma1234")
    m.screenshot(path=f"{SHOTS}/05-employee-home-mobile.png")
    overflow = m.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth")
    check("mobile : aucun défilement horizontal (accueil employé)", not overflow)
    m.click("text=Production du matin >> nth=0"); m.wait_for_selector(".stack .row")
    m.click(".stack .row >> nth=2"); m.wait_for_selector("#qty")
    m.fill("#qty", "1")
    m.wait_for_timeout(500)
    m.screenshot(path=f"{SHOTS}/06-employee-sheet-mobile.png")
    small = m.evaluate("""() => [...document.querySelectorAll('#sheet button, #sheet input, #sheet textarea')].filter(e => e.offsetParent && e.getBoundingClientRect().height < 40).map(e => e.id || e.textContent.trim().slice(0,20))""")
    check("mobile : boutons de la feuille de saisie ≥ 40 px", not small, str(small))
    m.click("[data-act=closeSheet]")
    mctx.close()

    mctx2 = browser.new_context(**iphone, locale="fr-FR", timezone_id="Europe/Paris")
    m2 = mctx2.new_page(); watch(m2)
    login(m2, "manager", "manager1234")
    m2.screenshot(path=f"{SHOTS}/07-manager-dashboard-mobile.png", full_page=True)
    check("mobile : aucun défilement horizontal (tableau de bord manager)", not m2.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth"))
    m2.goto(URL + "#/lists"); m2.click("text=Nouvelle liste >> nth=0"); m2.wait_for_selector("#listForm")
    m2.screenshot(path=f"{SHOTS}/08-manager-editor-mobile.png")
    check("mobile : éditeur de liste sans débordement", not m2.evaluate("document.querySelector('.sheet').scrollWidth > document.querySelector('.sheet').clientWidth"))
    mctx2.close()

    check("aucune erreur JavaScript dans la console", not errors, "; ".join(errors[:5]))
    browser.close()

fails = [r for r in results if not r[0]]
print(f"\n{len(results) - len(fails)} réussis, {len(fails)} échecs")
sys.exit(1 if fails else 0)
