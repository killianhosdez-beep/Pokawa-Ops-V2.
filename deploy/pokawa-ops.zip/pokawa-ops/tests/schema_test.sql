-- Test du schéma contre un vrai Postgres, avec une imitation minimale de Supabase Auth.
-- Lancer : bash tests/run_schema_test.sh
\set ON_ERROR_STOP on
\pset pager off

-- ---- imitation de Supabase (rôles, schéma auth, auth.uid) ----
do $$ begin
  if not exists (select 1 from pg_roles where rolname = 'anon') then create role anon nologin; end if;
  if not exists (select 1 from pg_roles where rolname = 'authenticated') then create role authenticated nologin; end if;
end $$;
create schema if not exists auth;
create table if not exists auth.users (
  id uuid primary key default gen_random_uuid(), email text,
  raw_user_meta_data jsonb default '{}', raw_app_meta_data jsonb default '{}'
);
create or replace function auth.uid() returns uuid language sql stable as
  $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
grant usage on schema auth to authenticated, anon;
grant usage on schema public to authenticated, anon;

\i supabase/schema.sql
-- relancer le schéma une 2e fois : doit être sans effet (idempotence)
\i supabase/schema.sql

grant select, insert, update, delete on all tables in schema public to authenticated;
grant usage on all sequences in schema public to authenticated;

\o /dev/null
-- ---- comptes ----
insert into auth.users (id, email, raw_user_meta_data, raw_app_meta_data) values
 ('00000000-0000-0000-0000-0000000000a1', 'admin@x',   '{"full_name":"Alice Admin"}', '{"provisioned":"true"}'),
 ('00000000-0000-0000-0000-0000000000b1', 'manager@x', '{"full_name":"Marc Manager"}', '{"provisioned":"true"}'),
 ('00000000-0000-0000-0000-0000000000c1', 'emp@x',     '{"full_name":"Emma Employée"}', '{"provisioned":"true"}'),
 ('00000000-0000-0000-0000-0000000000d1', 'rogue@x',   '{"full_name":"Inscrit libre"}', '{}');
update public.profiles set role = 'admin'   where id = '00000000-0000-0000-0000-0000000000a1';
update public.profiles set role = 'manager' where id = '00000000-0000-0000-0000-0000000000b1';

create temp table results(name text, ok boolean, detail text);
grant all on results to authenticated;

-- aide : attendre qu'une instruction échoue avec un message contenant `needle`
create or replace function pg_temp.expect_error(name text, stmt text, needle text) returns void language plpgsql as $$
begin
  begin
    execute stmt;
    insert into results values (name, false, 'aucune erreur alors qu''une était attendue');
  exception when others then
    insert into results values (name, position(lower(needle) in lower(sqlerrm)) > 0, sqlerrm);
  end;
end $$;
create or replace function pg_temp.check(name text, cond boolean, detail text default '') returns void language sql as
  $$ insert into results values (name, coalesce(cond, false), detail) $$;
grant execute on function pg_temp.expect_error(text,text,text), pg_temp.check(text,boolean,text) to authenticated;

create or replace function pg_temp.expect_zero_rows(name text, stmt text) returns void language plpgsql as $$
declare n int;
begin
  begin
    execute stmt; get diagnostics n = row_count;
    insert into results values (name, n = 0, n || ' ligne(s) modifiée(s)');
  exception when others then
    insert into results values (name, true, 'refusé : ' || sqlerrm);
  end;
end $$;
grant execute on function pg_temp.expect_zero_rows(text,text) to authenticated;

-- ---- scénario du cahier des charges ----
select pg_temp.check('inscription libre = compte inactif', (select not active from public.profiles where id = '00000000-0000-0000-0000-0000000000d1'));

set role authenticated;
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000b1';   -- manager

insert into public.lists (id, name, type_id, work_date, period, instructions, created_by)
  select '10000000-0000-0000-0000-000000000001', 'Production du matin', id, current_date, 'morning', 'Étiqueter tous les bacs', '00000000-0000-0000-0000-0000000000b1'
  from public.list_types where name = 'Production du matin';
insert into public.list_items (id, list_id, product, requested_qty, unit, sort_order) values
  ('20000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 'Riz', 12, 'kg', 0),
  ('20000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000001', 'Sauce fromagère', 4, 'L', 1);

select pg_temp.expect_error('publier une liste vide est refusé',
  $q$select public.set_list_status((select id from public.lists where name='Production du matin' and id <> '10000000-0000-0000-0000-000000000001' limit 1), 'published')$q$, 'introuvable');

reset role; set role authenticated;
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000c1';   -- employé
select pg_temp.check('employé ne voit pas une liste en brouillon', (select count(*) = 0 from public.lists));

set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000b1';
select public.set_list_status('10000000-0000-0000-0000-000000000001', 'published');

set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000c1';
select pg_temp.check('employé voit la liste publiée et ses lignes',
  (select count(*) = 1 from public.lists) and (select count(*) = 2 from public.list_items));

-- l'employé ne peut rien modifier directement
select pg_temp.expect_zero_rows('employé ne peut pas changer la quantité demandée',
  $q$update public.list_items set requested_qty = 1 where id = '20000000-0000-0000-0000-000000000001'$q$);
select pg_temp.expect_zero_rows('employé ne peut pas supprimer une ligne',
  $q$delete from public.list_items where id = '20000000-0000-0000-0000-000000000001'$q$);
select pg_temp.expect_zero_rows('employé ne peut pas modifier les consignes générales',
  $q$update public.lists set instructions = 'piraté' where id = '10000000-0000-0000-0000-000000000001'$q$);
select pg_temp.check('… la quantité demandée est restée 12',
  (select requested_qty = 12 from public.list_items where id = '20000000-0000-0000-0000-000000000001'));
select pg_temp.expect_error('employé ne peut pas écrire un résultat à la main',
  $q$insert into public.item_results (item_id, status) values ('20000000-0000-0000-0000-000000000001', 'done')$q$, 'row-level security');
select pg_temp.expect_error('employé ne peut pas créer de signalement à la main',
  $q$insert into public.reports (item_id, list_id, requested_qty, prepared_qty, missing_qty, reason) values ('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001',12,12,0,'x')$q$, 'row-level security');
select pg_temp.expect_error('employé ne peut pas lire l''historique', $q$select 1/(count(*)) from public.audit_events$q$, 'division');
select pg_temp.expect_error('employé ne peut pas décider', $q$select public.decide_report(gen_random_uuid(), 'accept', 'ok ok')$q$, 'management');
select pg_temp.expect_error('employé ne peut pas publier', $q$select public.set_list_status('10000000-0000-0000-0000-000000000001', 'closed')$q$, 'management');

-- test 1 : 12 kg → validation normale
select public.submit_item_result('20000000-0000-0000-0000-000000000001', 12, null, null);
select pg_temp.check('12 demandés / 12 préparés → done',
  (select status = 'done' and missing_qty = 0 from public.item_results where item_id = '20000000-0000-0000-0000-000000000001'));
select pg_temp.expect_error('double validation refusée',
  $q$select public.submit_item_result('20000000-0000-0000-0000-000000000001', 12, null, null)$q$, 'déjà validée');

-- test 2 / 3 / 4 : 9 kg
select pg_temp.expect_error('4 demandés / 3 préparés sans raison refusé',
  $q$select public.submit_item_result('20000000-0000-0000-0000-000000000002', 3, null, null)$q$, 'raison');
select pg_temp.expect_error('raison inventée refusée',
  $q$select public.submit_item_result('20000000-0000-0000-0000-000000000002', 3, 'Parce que', null)$q$, 'n’existe pas');
select pg_temp.expect_error('« Autre raison » sans commentaire refusé',
  $q$select public.submit_item_result('20000000-0000-0000-0000-000000000002', 3, 'Autre raison', '')$q$, 'commentaire');
select pg_temp.expect_error('quantité négative refusée',
  $q$select public.submit_item_result('20000000-0000-0000-0000-000000000002', -1, 'Rupture de stock', null)$q$, 'quantité valide');
select pg_temp.check('… rien n''a été enregistré par les refus (ligne toujours « à faire »)',
  not exists (select 1 from public.item_results where item_id = '20000000-0000-0000-0000-000000000002' and status <> 'todo')
  and not exists (select 1 from public.reports where item_id = '20000000-0000-0000-0000-000000000002'));

select public.submit_item_result('20000000-0000-0000-0000-000000000002', 3, 'Rupture de stock', null);
select pg_temp.check('3/4 + Rupture de stock → partial, 1 L manquant',
  (select status = 'partial' and missing_qty = 1 from public.item_results where item_id = '20000000-0000-0000-0000-000000000002'));
select pg_temp.check('… signalement ouvert avec motif, nom et quantités',
  (select count(*) = 1 from public.reports where item_id = '20000000-0000-0000-0000-000000000002' and status = 'open'
     and reason = 'Rupture de stock' and missing_qty = 1 and requested_qty = 4 and prepared_qty = 3 and reported_by_name = 'Emma Employée'));

-- l'employé renvoie une autre quantité : toujours un seul signalement ouvert
select public.submit_item_result('20000000-0000-0000-0000-000000000002', 2, 'Manque de temps', null);
select pg_temp.check('renvoi partiel → toujours 1 seul signalement ouvert, mis à jour',
  (select count(*) = 1 and max(missing_qty) = 2 and max(reason) = 'Manque de temps' from public.reports where item_id = '20000000-0000-0000-0000-000000000002'));

-- test 5 : manager
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000b1';
select pg_temp.check('manager voit le signalement', (select count(*) = 1 from public.reports));
select pg_temp.expect_error('accepter l''écart sans justification refusé',
  $q$select public.decide_report((select id from public.reports limit 1), 'accept', '')$q$, 'justification');
select public.decide_report((select id from public.reports limit 1), 'complete', 'Refais 2 L avant 11h');
select pg_temp.check('« compléter » → ligne à corriger, signalement encore ouvert',
  (select status = 'to_fix' and manager_instruction = 'Refais 2 L avant 11h' from public.item_results where item_id = '20000000-0000-0000-0000-000000000002')
  and (select status = 'open' from public.reports limit 1));

set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000c1';
select public.submit_item_result('20000000-0000-0000-0000-000000000002', 4, null, null);
select pg_temp.check('l''employé complète → done et signalement résolu',
  (select status = 'done' from public.item_results where item_id = '20000000-0000-0000-0000-000000000002')
  and (select status = 'resolved' and decision = 'completed' from public.reports limit 1));

-- exception : ne devient jamais « done »
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000b1';
select public.reopen_item('20000000-0000-0000-0000-000000000002', 'Contrôle qualité');
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000c1';
select public.submit_item_result('20000000-0000-0000-0000-000000000002', 1, 'Problème matériel', null);
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000b1';
select public.decide_report((select id from public.reports where status = 'open'), 'accept', 'Validé avec le gérant');
select pg_temp.check('exception acceptée → gap_accepted (jamais done)',
  (select status = 'gap_accepted' from public.item_results where item_id = '20000000-0000-0000-0000-000000000002'));
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000c1';
select pg_temp.expect_error('l''employé ne peut pas revalider un écart accepté',
  $q$select public.submit_item_result('20000000-0000-0000-0000-000000000002', 4, null, null)$q$, 'déjà validée');

-- surplus et règle « justify »
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000b1';
select public.reopen_item('20000000-0000-0000-0000-000000000001', null);
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000c1';
select pg_temp.expect_error('surplus sans commentaire refusé (règle justify)',
  $q$select public.submit_item_result('20000000-0000-0000-0000-000000000001', 14, null, null)$q$, 'dépasse');
select public.submit_item_result('20000000-0000-0000-0000-000000000001', 14, null, 'Lot entamé');
select pg_temp.check('surplus signalé : done avec 2 kg de surplus',
  (select status = 'done' and surplus_qty = 2 from public.item_results where item_id = '20000000-0000-0000-0000-000000000001'));

-- liste clôturée : plus de saisie
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000b1';
select pg_temp.expect_error('repasser en brouillon refusé quand du travail est enregistré',
  $q$select public.set_list_status('10000000-0000-0000-0000-000000000001', 'draft')$q$, 'brouillon');
update public.list_items set requested_qty = 13 where id = '20000000-0000-0000-0000-000000000001';
select pg_temp.check('modification après publication tracée dans l''historique',
  (select count(*) >= 1 from public.audit_events where action = 'modification_apres_publication'));
select public.set_list_status('10000000-0000-0000-0000-000000000001', 'closed');
set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000c1';
select pg_temp.expect_error('saisie impossible sur une liste clôturée',
  $q$select public.submit_item_result('20000000-0000-0000-0000-000000000002', 4, null, null)$q$, 'pas ouverte');

-- compte désactivé
reset role;
update public.profiles set active = false where id = '00000000-0000-0000-0000-0000000000c1';
set role authenticated; set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000c1';
select pg_temp.check('compte désactivé : ne voit plus rien', (select count(*) = 0 from public.lists));
select pg_temp.expect_error('compte désactivé : saisie refusée',
  $q$select public.submit_item_result('20000000-0000-0000-0000-000000000002', 4, null, null)$q$, 'inactif');

-- historique complet (manager)
reset role; set role authenticated; set request.jwt.claim.sub = '00000000-0000-0000-0000-0000000000b1';
select pg_temp.check('historique : actions principales présentes',
  (select count(distinct action) >= 8 from public.audit_events), (select string_agg(distinct action, ', ') from public.audit_events));
select pg_temp.check('historique : acteurs nommés', (select count(*) = 0 from public.audit_events where actor_name is null and action <> 'compte_modifie'));

-- duplication
create temp table dup(id uuid); grant all on dup to authenticated;
insert into dup select public.duplicate_list('10000000-0000-0000-0000-000000000001', current_date + 1);
select pg_temp.check('duplication : copie en brouillon, 2 lignes, aucun résultat copié',
  (select count(*) = 1 from public.lists l join dup on dup.id = l.id where l.status = 'draft')
  and (select count(*) = 2 from public.list_items i join dup on dup.id = i.list_id)
  and (select count(*) = 0 from public.item_results r join public.list_items i on i.id = r.item_id join dup on dup.id = i.list_id));

reset role;
\o
select case when ok then 'OK  ' else 'ÉCHEC' end as etat, name, case when ok then '' else detail end as detail from results order by ok, name;
select count(*) filter (where ok) as reussis, count(*) filter (where not ok) as echecs from results;
