// Lancer : node --test tests/*.test.js
const test = require('node:test');
const assert = require('node:assert/strict');
const L = require('../js/logic.js');

test('12 demandés, 12 préparés → validation normale', () => {
  const r = L.evaluateSubmission({ requested: 12, prepared: '12' });
  assert.equal(r.ok, true);
  assert.equal(r.status, 'done');
  assert.equal(r.needsReport, false);
});

test('12 demandés, 9 préparés sans raison → refusé', () => {
  const r = L.evaluateSubmission({ requested: 12, prepared: 9 });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'reason_required');
  assert.equal(r.missing, 3);
});

test('12 demandés, 9 préparés + « Rupture de stock » → partiel, 3 manquants', () => {
  const r = L.evaluateSubmission({ requested: 12, prepared: 9, reason: 'Rupture de stock' });
  assert.equal(r.ok, true);
  assert.equal(r.status, 'partial');
  assert.equal(r.missing, 3);
  assert.equal(r.needsReport, true);
});

test('« Autre raison » exige un commentaire', () => {
  const sans = L.evaluateSubmission({ requested: 12, prepared: 9, reason: L.OTHER_REASON });
  assert.equal(sans.ok, false);
  assert.equal(sans.code, 'comment_required');
  const avec = L.evaluateSubmission({ requested: 12, prepared: 9, reason: L.OTHER_REASON, comment: 'Four en panne' });
  assert.equal(avec.ok, true);
  assert.equal(avec.status, 'partial');
});

test('une raison inventée est refusée', () => {
  const r = L.evaluateSubmission({ requested: 12, prepared: 9, reason: 'Parce que' });
  assert.equal(r.ok, false);
  assert.equal(r.code, 'reason_invalid');
});

test('surplus : signalé, justification selon la règle du management', () => {
  const permissif = L.evaluateSubmission({ requested: 12, prepared: 14, surplusPolicy: 'allow' });
  assert.equal(permissif.ok, true);
  assert.equal(permissif.status, 'done');
  assert.equal(permissif.surplus, 2);
  const strict = L.evaluateSubmission({ requested: 12, prepared: 14, surplusPolicy: 'justify' });
  assert.equal(strict.ok, false);
  assert.equal(strict.code, 'surplus_comment_required');
  assert.equal(L.evaluateSubmission({ requested: 12, prepared: 14, surplusPolicy: 'justify', comment: 'Lot entamé' }).ok, true);
});

test('quantités invalides : texte, négatif, vide', () => {
  ['abc', '-3', '', null, undefined, '12 kg'].forEach((v) => {
    assert.equal(L.evaluateSubmission({ requested: 12, prepared: v }).code, 'invalid_quantity', String(v));
  });
});

test('virgule française et décimaux sans erreur d’arrondi', () => {
  assert.equal(L.parseQty('12,5'), 12.5);
  assert.equal(L.compare(0.3, 0.1 + 0.2).kind, 'equal');
  assert.equal(L.compare('2,5', '2.5').kind, 'equal');
  assert.equal(L.fmtQty(12.5), '12,5');
});

test('statuts : seuls certains permettent un nouvel envoi', () => {
  ['todo', 'in_progress', 'to_fix', 'partial'].forEach((s) => assert.equal(L.canSubmitFrom(s), true, s));
  ['done', 'gap_accepted'].forEach((s) => assert.equal(L.canSubmitFrom(s), false, s));
});

test('décisions : une exception ne rend jamais la production « terminée »', () => {
  ['accept', 'close'].forEach((d) => {
    const r = L.evaluateDecision(d, 'Validé avec le gérant');
    assert.equal(r.ok, true);
    assert.equal(r.itemStatus, 'gap_accepted');
    assert.notEqual(r.itemStatus, 'done');
  });
  assert.equal(L.evaluateDecision('accept', '').ok, false);
  assert.equal(L.evaluateDecision('inconnue', 'x').ok, false);
  assert.equal(L.evaluateDecision('complete', '').itemStatus, 'to_fix');
});

test('synthèse : 10 tâches, 7 finies, 2 en cours, 1 partielle', () => {
  const statuses = [...Array(7).fill('done'), 'in_progress', 'in_progress', 'partial'];
  const s = L.summarize(statuses, 1);
  assert.equal(s.total, 10);
  assert.equal(s.done, 7);
  assert.equal(s.in_progress, 2);
  assert.equal(s.partial, 1);
  assert.equal(s.waitingManager, 1);
  assert.equal(s.remaining, 3);
  assert.equal(s.pct, 70);
  assert.equal(s.finished, false);
});

test('retard : heure limite dépassée ou jour passé', () => {
  const list = { status: 'published', work_date: '2026-11-22', due_time: '11:00' };
  assert.equal(L.isOverdue(list, 2, new Date(2026, 10, 22, 10, 59)), false);
  assert.equal(L.isOverdue(list, 2, new Date(2026, 10, 22, 11, 1)), true);
  assert.equal(L.isOverdue(list, 0, new Date(2026, 10, 22, 12, 0)), false);
  assert.equal(L.isOverdue({ ...list, status: 'draft' }, 2, new Date(2026, 10, 22, 12, 0)), false);
  assert.equal(L.isOverdue(list, 1, new Date(2026, 10, 23, 8, 0)), true);
});

test('export CSV : guillemets et séparateurs protégés', () => {
  assert.equal(L.csvCell('a;b'), '"a;b"');
  assert.equal(L.csvCell('dit "oui"'), '"dit ""oui"""');
  assert.equal(L.csvCell(null), '');
});
