/* Backend « réel » : Supabase (Auth + Postgres + Realtime + fonction Edge).
 * Même interface que backend-local.js. Les règles métier sont appliquées par la base
 * (supabase/schema.sql) ; ce fichier ne fait que transporter les demandes.
 */
(function () {
  'use strict';
  const L = window.Logic;
  const CFG = window.POKAWA_CONFIG || {};
  let sb = null;
  let me = null;

  const fail = (msg) => { throw new Error(msg); };
  const emailFor = (username) => {
    const u = String(username || '').trim().toLowerCase();
    return u.includes('@') ? u : u + '@' + (CFG.AUTH_DOMAIN || 'pokawa-ops.local');
  };
  const nice = (error) => {
    const m = (error && error.message) || String(error);
    if (/Invalid login credentials/i.test(m)) return 'Identifiant ou mot de passe incorrect.';
    if (/Failed to fetch|NetworkError|Load failed/i.test(m)) return 'Connexion impossible. Vérifie le réseau puis réessaie.';
    if (/duplicate key|23505/.test(m)) return 'Cet élément existe déjà.';
    return m;
  };
  const check = ({ data, error }) => { if (error) fail(nice(error)); return data; };

  // PostgREST renvoie au plus 1000 lignes par requête : on pagine.
  async function all(build) {
    const out = [];
    for (let from = 0; ; from += 1000) {
      const rows = check(await build().range(from, from + 999));
      out.push(...rows);
      if (rows.length < 1000) return out;
    }
  }
  const num = (v) => (v === null || v === undefined ? v : Number(v));

  async function loadProfile(userId) {
    const { data, error } = await sb.from('profiles').select('id, full_name, role, active').eq('id', userId).maybeSingle();
    if (error) fail(nice(error));
    return data;
  }

  async function ensureLib() {
    if (window.supabase && window.supabase.createClient) return;
    await new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js';
      s.onload = resolve;
      s.onerror = () => reject(new Error('Impossible de charger la bibliothèque Supabase. Vérifie la connexion.'));
      document.head.appendChild(s);
    });
  }

  const Backend = {
    mode: 'live',
    demoAccounts: [],

    async init() {
      await ensureLib();
      sb = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true } });
      const { data } = await sb.auth.getSession();
      if (!data.session) return null;
      const p = await loadProfile(data.session.user.id);
      if (!p || !p.active) { await sb.auth.signOut(); return null; }
      me = p;
      return me;
    },
    async signIn(username, password) {
      const { data, error } = await sb.auth.signInWithPassword({ email: emailFor(username), password });
      if (error) fail(nice(error));
      const p = await loadProfile(data.user.id);
      if (!p || !p.active) {
        await sb.auth.signOut();
        fail('Ce compte est désactivé ou en attente d’activation. Demande à un administrateur.');
      }
      me = p;
      return me;
    },
    async signOut() { await sb.auth.signOut(); me = null; },

    async load({ since }) {
      const manager = me.role !== 'employee';
      const [profiles, types, lists, items, results, reports, audit] = await Promise.all([
        all(() => sb.from('profiles').select('id, full_name, role, active').order('full_name')),
        all(() => sb.from('list_types').select('*').order('sort_order')),
        all(() => sb.from('lists').select('*').gte('work_date', since).order('work_date', { ascending: false }).order('created_at')),
        all(() => sb.from('list_items').select('*, lists!inner(work_date)').gte('lists.work_date', since).order('sort_order')),
        all(() => sb.from('item_results').select('*, list_items!inner(lists!inner(work_date))').gte('list_items.lists.work_date', since)),
        all(() => sb.from('reports').select('*').gte('reported_at', since + 'T00:00:00').order('reported_at', { ascending: false })),
        manager ? all(() => sb.from('audit_events').select('*').gte('at', since + 'T00:00:00').order('at', { ascending: false }).limit(1000)) : Promise.resolve([])
      ]);
      items.forEach((i) => { delete i.lists; i.requested_qty = num(i.requested_qty); });
      results.forEach((r) => { delete r.list_items; ['prepared_qty', 'missing_qty', 'surplus_qty'].forEach((k) => { r[k] = num(r[k]); }); });
      reports.forEach((r) => ['requested_qty', 'prepared_qty', 'missing_qty'].forEach((k) => { r[k] = num(r[k]); }));
      return { profiles, types, lists, items, results, reports, audit };
    },
    subscribe(cb) {
      let timer = null;
      const kick = () => { clearTimeout(timer); timer = setTimeout(cb, 300); };
      const ch = sb.channel('pokawa-ops');
      ['lists', 'list_items', 'item_results', 'reports'].forEach((table) => ch.on('postgres_changes', { event: '*', schema: 'public', table }, kick));
      ch.subscribe();
      return () => { clearTimeout(timer); sb.removeChannel(ch); };
    },

    // ---------- employé ----------
    async startItem(itemId) { check(await sb.rpc('start_item', { p_item_id: itemId })); },
    async submitResult(itemId, prepared, reason, comment) {
      const q = L.parseQty(prepared);
      if (Number.isNaN(q)) fail('Saisis une quantité valide (nombre positif, par exemple 12 ou 12,5).');
      check(await sb.rpc('submit_item_result', { p_item_id: itemId, p_prepared: q, p_reason: reason || null, p_comment: comment || null }));
    },

    // ---------- management ----------
    async saveList(list, items) {
      if (!String(list.name || '').trim()) fail('Donne un nom à la liste.');
      if (!items.length) fail('Ajoute au moins un produit.');
      items.forEach((it, n) => {
        if (!String(it.product || '').trim()) fail('Ligne ' + (n + 1) + ' : indique le produit.');
        if (!(L.parseQty(it.requested_qty) > 0)) fail('Ligne ' + (n + 1) + ' : la quantité demandée doit être supérieure à 0.');
        if (!String(it.unit || '').trim()) fail('Ligne ' + (n + 1) + ' : indique l’unité.');
      });
      const fields = {
        name: list.name.trim(), type_id: list.type_id || null, work_date: list.work_date, period: list.period,
        due_time: list.due_time || null, instructions: (list.instructions || '').trim() || null,
        surplus_policy: list.surplus_policy || 'justify', updated_at: new Date().toISOString()
      };
      let id = list.id;
      if (id) check(await sb.from('lists').update(fields).eq('id', id));
      else id = check(await sb.from('lists').insert({ ...fields, created_by: me.id }).select('id').single()).id;

      if (list.id) {
        const existing = check(await sb.from('list_items').select('id').eq('list_id', id));
        const keep = new Set(items.filter((i) => i.id).map((i) => i.id));
        const removed = existing.map((e) => e.id).filter((x) => !keep.has(x));
        if (removed.length) check(await sb.from('list_items').delete().in('id', removed));
      }
      const row = (it, n) => ({ list_id: id, product: it.product.trim(), requested_qty: L.parseQty(it.requested_qty), unit: it.unit.trim(), comment: (it.comment || '').trim() || null, sort_order: n });
      const withId = items.map((it, n) => ({ it, n })).filter((x) => x.it.id);
      const fresh = items.map((it, n) => ({ it, n })).filter((x) => !x.it.id);
      if (withId.length) check(await sb.from('list_items').upsert(withId.map(({ it, n }) => ({ id: it.id, ...row(it, n) }))));
      if (fresh.length) check(await sb.from('list_items').insert(fresh.map(({ it, n }) => row(it, n))));
      return id;
    },
    async setListStatus(listId, status) { check(await sb.rpc('set_list_status', { p_list_id: listId, p_status: status })); },
    async duplicateList(listId, date) { return check(await sb.rpc('duplicate_list', { p_list_id: listId, p_date: date })); },
    async decideReport(reportId, decision, note) {
      const ev = L.evaluateDecision(decision, note);
      if (!ev.ok) fail(ev.error);
      check(await sb.rpc('decide_report', { p_report_id: reportId, p_decision: decision, p_note: note || null }));
    },
    async reopenItem(itemId, note) { check(await sb.rpc('reopen_item', { p_item_id: itemId, p_note: note || null })); },
    async saveType(type) {
      const name = String(type.name || '').trim();
      if (!name) fail('Donne un nom au type de liste.');
      if (type.id) check(await sb.from('list_types').update({ name, color: type.color, active: type.active !== false }).eq('id', type.id));
      else check(await sb.from('list_types').insert({ name, color: type.color || '#0B3C5D', sort_order: 99 }));
    },

    // ---------- administration ----------
    async saveProfile(id, patch) {
      if (id === me.id && (patch.active === false || (patch.role && patch.role !== 'admin'))) fail('Tu ne peux pas retirer tes propres droits d’administrateur.');
      check(await sb.from('profiles').update(patch).eq('id', id));
    },
    async createAccount(payload) { await invoke({ action: 'create', ...payload }); },
    async resetPassword(id, password) { await invoke({ action: 'reset_password', user_id: id, password }); },
    async resetDemo() { fail('Réinitialisation disponible uniquement en mode démo.'); }
  };

  async function invoke(body) {
    const { data, error } = await sb.functions.invoke('admin-users', { body });
    if (error) {
      let msg = nice(error);
      try { const j = await error.context.json(); if (j && j.error) msg = j.error; } catch (e) { /* message par défaut */ }
      fail(msg);
    }
    if (data && data.error) fail(data.error);
    return data;
  }

  window.LiveBackend = Backend;
})();
