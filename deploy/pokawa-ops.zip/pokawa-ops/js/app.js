/* Pokawa Ops — noyau de l'application : état, navigation, connexion, espace employé.
 * Les écrans du management sont dans js/app-manager.js (même espace de noms window.App).
 */
(function () {
  'use strict';
  const L = window.Logic;
  const CFG = window.POKAWA_CONFIG || {};
  const LIVE = Boolean(CFG.SUPABASE_URL && CFG.SUPABASE_ANON_KEY);
  const Backend = LIVE ? window.LiveBackend : window.LocalBackend;

  const App = (window.App = {
    L, Backend, LIVE,
    S: { user: null, data: null, idx: null, since: null, sync: 'ok', syncAt: null, route: '' },
    ui: { dashDate: null, listsDate: null, hist: null, histTab: 'lists', teamNew: false },
    acts: {}, views: {}, pendingRender: false
  });
  const S = App.S;

  // ---------------------------------------------------------------- utilitaires
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => [...(root || document).querySelectorAll(sel)];
  const qty = (n, unit) => L.fmtQty(n) + (unit ? ' ' + unit : '');
  const today = () => L.ymd(new Date());
  const shiftDate = (ymd, n) => { const d = new Date(ymd + 'T12:00:00'); d.setDate(d.getDate() + n); return L.ymd(d); };
  const fmtDate = (ymd) => new Intl.DateTimeFormat('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(ymd + 'T12:00:00'));
  const fmtDateShort = (ymd) => new Intl.DateTimeFormat('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' }).format(new Date(ymd + 'T12:00:00'));
  const fmtTime = (iso) => (iso ? new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' }).format(new Date(iso)) : '');
  const fmtDateTime = (iso) => (iso ? fmtDateShort(L.ymd(new Date(iso))) + ' · ' + fmtTime(iso) : '');
  const ROLE = { admin: 'Administrateur', manager: 'Manager', employee: 'Employé' };
  const PERIOD = { morning: 'Matin', afternoon: 'Après-midi', evening: 'Soir', all_day: 'Toute la journée' };
  const LIST_STATUS = { draft: ['Brouillon', 'todo'], published: ['Publiée', 'in_progress'], closed: ['Clôturée', 'done'] };
  Object.assign(App, { esc, $, $$, qty, today, shiftDate, fmtDate, fmtDateShort, fmtTime, fmtDateTime, ROLE, PERIOD, LIST_STATUS });

  const ICON = {
    home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11l8-7 8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/></svg>',
    flag: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 21V4m0 0h11l-2 4 2 4H5"/></svg>',
    list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    team: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.6-3.4 3.2-5 6.5-5s5.9 1.6 6.5 5M16 4.6a3.5 3.5 0 0 1 0 6.8M18 15.3c1.9.6 3.1 2.1 3.5 4.7"/></svg>',
    gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
    chev: '<svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
    back: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>'
  };
  App.ICON = ICON;

  const pill = (status) => {
    const st = L.STATUS[status] || L.STATUS.todo;
    return '<span class="pill" style="background:' + st.soft + ';color:' + st.color + '">' + esc(st.label) + '</span>';
  };
  const listStatusPill = (status) => pill(LIST_STATUS[status][1]).replace(esc(L.STATUS[LIST_STATUS[status][1]].label), LIST_STATUS[status][0]);
  Object.assign(App, { pill, listStatusPill });

  // ---------------------------------------------------------------- messages, fenêtres
  let toastTimer = null;
  function toast(msg, kind) {
    const el = $('#toast');
    el.textContent = msg; el.className = 'toast' + (kind ? ' ' + kind : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.add('hidden'), kind === 'bad' ? 6000 : 3500);
  }
  function openSheet(html, opts) {
    const d = $('#sheet');
    d.innerHTML = '<div class="sheet' + (opts && opts.wide ? ' wide' : '') + '"><div class="grab"></div>' + html + '</div>';
    if (!d.open) d.showModal();
    const first = $('[autofocus]', d); if (first) first.focus();
    return d;
  }
  function closeSheet() { const d = $('#sheet'); if (d.open) d.close(); d.innerHTML = ''; }
  function confirmBox(message, opts) {
    opts = opts || {};
    return new Promise((resolve) => {
      const d = document.createElement('dialog');
      d.innerHTML = '<div class="sheet"><div class="grab"></div><h2>' + esc(opts.title || 'Confirmer') + '</h2><p>' + esc(message) +
        '</p><div class="btn-row"><button class="btn" data-v="0">' + esc(opts.cancel || 'Annuler') + '</button><button class="btn ' + (opts.danger ? 'danger' : 'primary') + '" data-v="1">' + esc(opts.ok || 'Confirmer') + '</button></div></div>';
      document.body.appendChild(d);
      const done = (v) => { d.close(); d.remove(); resolve(v); };
      d.addEventListener('click', (e) => { const b = e.target.closest('[data-v]'); if (b) done(b.dataset.v === '1'); else if (e.target === d) done(false); });
      d.addEventListener('cancel', (e) => { e.preventDefault(); done(false); });
      d.showModal();
    });
  }
  Object.assign(App, { toast, openSheet, closeSheet, confirmBox });
  $('#sheet').addEventListener('click', (e) => { if (e.target.id === 'sheet') closeSheet(); });

  // ---------------------------------------------------------------- données et index
  function buildIndex(data) {
    const idx = { type: {}, list: {}, item: {}, result: {}, itemsByList: {}, reportByItem: {}, openReports: [], profile: {} };
    data.profiles.forEach((p) => { idx.profile[p.id] = p; });
    data.types.forEach((t) => { idx.type[t.id] = t; });
    data.lists.forEach((l) => { idx.list[l.id] = l; idx.itemsByList[l.id] = []; });
    data.items.forEach((i) => { idx.item[i.id] = i; (idx.itemsByList[i.list_id] || (idx.itemsByList[i.list_id] = [])).push(i); });
    Object.values(idx.itemsByList).forEach((a) => a.sort((x, y) => x.sort_order - y.sort_order));
    data.results.forEach((r) => { idx.result[r.item_id] = r; });
    data.reports.forEach((r) => {
      const prev = idx.reportByItem[r.item_id];
      if (!prev || (r.status === 'open' && prev.status !== 'open') || (r.status === prev.status && r.reported_at > prev.reported_at)) idx.reportByItem[r.item_id] = r;
      if (r.status === 'open') idx.openReports.push(r);
    });
    idx.openReports.sort((a, b) => (a.reported_at < b.reported_at ? 1 : -1));
    return idx;
  }
  const statusOf = (itemId) => (S.idx.result[itemId] && S.idx.result[itemId].status) || 'todo';
  function summaryOf(listId) {
    const items = S.idx.itemsByList[listId] || [];
    const open = S.data.reports.filter((r) => r.list_id === listId && r.status === 'open').length;
    return L.summarize(items.map((i) => statusOf(i.id)), open);
  }
  const isManager = () => S.user && S.user.role !== 'employee';
  const isAdmin = () => S.user && S.user.role === 'admin';
  Object.assign(App, { statusOf, summaryOf, isManager, isAdmin });

  async function reload(silent) {
    if (!S.user) return;
    try {
      const data = await Backend.load({ since: S.since });
      S.data = data; S.idx = buildIndex(data); S.sync = 'ok'; S.syncAt = new Date();
    } catch (err) {
      S.sync = 'err';
      if (!S.data) { toast(err.message, 'bad'); }
      if (!silent) toast('Actualisation impossible : ' + err.message, 'bad');
    }
    softRender();
  }
  App.reload = reload;

  // Ne pas écraser ce que la personne est en train de taper.
  function softRender() {
    const a = document.activeElement;
    if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.closest('#view')) { App.pendingRender = true; return; }
    App.pendingRender = false;
    render();
  }
  document.addEventListener('focusout', () => { if (App.pendingRender) setTimeout(() => { if (App.pendingRender) softRender(); }, 150); });

  // ---------------------------------------------------------------- navigation
  function route() {
    const h = (location.hash || '').replace(/^#\/?/, '');
    const [name, arg] = h.split('/');
    const home = isManager() ? 'dash' : 'today';
    return { name: name || home, arg: arg || null };
  }
  const go = (path) => { location.hash = '#/' + path; };
  App.go = go;
  window.addEventListener('hashchange', () => { if (S.user) render(); });

  function navItems() {
    if (!isManager()) return [['today', 'Aujourd’hui', ICON.home], ['mine', 'Mes signalements', ICON.flag]];
    const items = [['dash', 'Accueil', ICON.home], ['reports', 'Signalements', ICON.flag], ['lists', 'Listes', ICON.list], ['history', 'Historique', ICON.clock]];
    if (isAdmin()) items.push(['team', 'Équipe', ICON.team]);
    items.push(['settings', 'Réglages', ICON.gear]);
    return items;
  }

  function render() {
    const root = $('#app');
    if (!S.user) { root.innerHTML = loginView(); return; }
    if (!S.data) { root.innerHTML = '<div class="loader">Chargement des listes…</div>'; return; }
    const r = route();
    const nav = navItems();
    const active = nav.find((n) => n[0] === r.name || (r.name === 'list' && n[0] === (isManager() ? 'lists' : 'today'))) || nav[0];
    const open = S.idx.openReports.length;
    const view = App.views[(isManager() ? 'm_' : 'e_') + r.name] || (isManager() ? App.views.m_dash : App.views.e_today);
    let body;
    try { body = view(r.arg); } catch (err) { console.error(err); body = '<div class="banner bad">Cet écran n’a pas pu s’afficher : ' + esc(err.message) + '</div>'; }
    const sync = S.sync === 'err' ? '<span class="sync err">Hors connexion</span>' : '<span class="sync">Synchronisé ' + fmtTime(S.syncAt) + '</span>';
    root.innerHTML =
      '<div class="shell">' +
      '<header class="topbar"><span class="brand"><i></i>' + esc(CFG.RESTAURANT || 'Pokawa') + ' Ops</span>' + sync +
      '<span class="who"><b>' + esc(S.user.full_name) + '</b>' + esc(ROLE[S.user.role]) + '</span><button data-act="logout">Quitter</button></header>' +
      '<main class="view-wrap">' + (LIVE ? '' : '<div class="demo-flag">Mode démo : les données restent sur cet appareil</div>') + '<div class="view" id="view">' + body + '</div></main>' +
      '<nav class="nav" aria-label="Navigation">' + nav.map((n) =>
        '<a href="#/' + n[0] + '"' + (n === active ? ' aria-current="page"' : '') + '>' + n[2] + '<span>' + esc(n[1]) + '</span>' +
        (n[0] === 'reports' && open ? '<span class="badge" aria-label="' + open + ' à traiter">' + open + '</span>' : '') + '</a>').join('') + '</nav></div>';
  }

  // ---------------------------------------------------------------- connexion
  function loginView() {
    const demo = Backend.demoAccounts || [];
    return '<div class="login"><div class="brand"><i></i>' + esc(CFG.RESTAURANT || 'Pokawa') + ' Ops</div>' +
      '<form class="card" data-form="login" autocomplete="on"><div><h1>Connexion</h1><p class="muted">Utilise l’identifiant donné par ton manager.</p></div>' +
      '<label class="field"><span>Identifiant</span><input type="text" name="username" autocomplete="username" autocapitalize="none" autocorrect="off" required autofocus></label>' +
      '<label class="field"><span>Mot de passe</span><input type="password" name="password" autocomplete="current-password" required></label>' +
      '<p class="error" id="loginError" role="alert"></p>' +
      '<button class="btn primary block" type="submit">Se connecter</button>' +
      (demo.length ? '<div class="banner info"><div><b>Mode démo.</b> Choisis un profil pour essayer sans rien configurer.<div class="demo-accounts" style="margin-top:8px">' +
        demo.map((d) => '<button type="button" class="btn sm" data-act="demoLogin" data-u="' + esc(d.username) + '" data-p="' + esc(d.password) + '">' + esc(d.label) + '</button>').join('') + '</div></div></div>' : '') +
      '</form></div>';
  }
  async function doLogin(username, password) {
    const err = $('#loginError'); if (err) err.textContent = '';
    try {
      S.user = await Backend.signIn(username, password);
      await start();
    } catch (e) { if (err) err.textContent = e.message; else toast(e.message, 'bad'); }
  }
  let unsub = null;
  async function start() {
    S.since = shiftDate(today(), -45);
    S.data = null; render();
    await reload(true);
    if (unsub) unsub();
    unsub = Backend.subscribe(() => reload(true));
    if (!location.hash) go(isManager() ? 'dash' : 'today');
    render();
  }

  // ---------------------------------------------------------------- événements globaux
  App.acts.logout = async () => { if (unsub) unsub(); await Backend.signOut(); S.user = null; S.data = null; location.hash = ''; render(); };
  App.acts.demoLogin = (el) => doLogin(el.dataset.u, el.dataset.p);
  App.acts.closeSheet = closeSheet;
  App.acts.openItem = (el) => App.openItemSheet(el.dataset.id);

  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act]');
    if (!el) return;
    const fn = App.acts[el.dataset.act];
    if (fn) { e.preventDefault(); Promise.resolve(fn(el, e)).catch((err) => { console.error(err); toast(err.message || String(err), 'bad'); }); }
  });
  document.addEventListener('submit', (e) => {
    const f = e.target.closest('[data-form]');
    if (!f) return;
    e.preventDefault();
    if (f.dataset.form === 'login') { const d = new FormData(f); doLogin(d.get('username'), d.get('password')); return; }
    const fn = App.acts['form_' + f.dataset.form];
    if (fn) Promise.resolve(fn(f, e)).catch((err) => { console.error(err); toast(err.message || String(err), 'bad'); });
  });
  document.addEventListener('change', (e) => {
    const el = e.target.closest('[data-change]');
    if (el && App.acts[el.dataset.change]) Promise.resolve(App.acts[el.dataset.change](el, e)).catch((err) => { toast(err.message || String(err), 'bad'); });
  });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && S.user) reload(true); });
  window.addEventListener('online', () => { if (S.user) reload(true); });
  window.addEventListener('offline', () => { S.sync = 'err'; if (S.user) render(); });

  // ================================================================ ESPACE EMPLOYÉ
  function sortLists(a, b) {
    return (a.work_date < b.work_date ? -1 : a.work_date > b.work_date ? 1 : 0) || String(a.due_time || '99').localeCompare(String(b.due_time || '99')) || a.name.localeCompare(b.name);
  }
  function typeOf(list) { return S.idx.type[list.type_id] || { name: 'Liste', color: '#0B2F45' }; }

  function listRow(list) {
    const s = summaryOf(list.id); const t = typeOf(list);
    const late = L.isOverdue(list, s.remaining, new Date());
    return '<a class="row" href="#/list/' + esc(list.id) + '"><span class="stripe" style="background:' + esc(t.color) + '"></span><span class="main">' +
      '<span class="title">' + esc(list.name) + '</span>' +
      '<span class="meta">' + (t.name !== list.name ? esc(t.name) : esc(PERIOD[list.period])) + (list.work_date !== today() ? ' · ' + esc(fmtDateShort(list.work_date)) : '') + (list.due_time ? ' · avant ' + esc(list.due_time.slice(0, 5)) : '') + '</span>' +
      '<span class="gauge" aria-hidden="true"><span class="fill' + (s.finished ? ' ok' : '') + '" style="width:' + s.pct + '%"></span></span>' +
      '<span class="meta"><b class="num">' + s.done + ' / ' + s.total + '</b> terminées' + (s.partial ? ' · ' + s.partial + ' en attente du management' : '') + (s.to_fix ? ' · <b style="color:var(--bad)">' + s.to_fix + ' à corriger</b>' : '') + (late ? ' · <b style="color:var(--bad)">en retard</b>' : '') + '</span>' +
      '</span>' + ICON.chev + '</a>';
  }

  App.views.e_today = function () {
    const lists = S.data.lists.filter((l) => l.status === 'published' && (l.work_date === today() || (l.work_date < today() && summaryOf(l.id).remaining > 0))).sort(sortLists);
    return '<div class="head"><div><h1>Aujourd’hui</h1><p class="sub">' + esc(fmtDate(today())) + '</p></div></div>' +
      (lists.length ? '<div class="stack">' + lists.map(listRow).join('') + '</div>'
        : '<div class="panel empty"><h2>Aucune liste à faire</h2><p>Quand ton manager publiera une liste, elle apparaîtra ici automatiquement.</p><button class="btn" data-act="refresh">Actualiser</button></div>');
  };
  App.acts.refresh = () => reload(false);

  App.views.e_list = function (id) { return listDetail(id, false); };
  App.views.m_list = function (id) { return listDetail(id, true); };

  function itemRow(item, list, manager) {
    const r = S.idx.result[item.id] || null; const st = r ? r.status : 'todo'; const rep = S.idx.reportByItem[item.id];
    const color = L.STATUS[st].color;
    let line = '<span class="meta">Demandé <b class="num">' + esc(qty(item.requested_qty, item.unit)) + '</b>';
    if (r && r.prepared_qty != null) line += ' · Préparé <b class="num">' + esc(qty(r.prepared_qty, item.unit)) + '</b>';
    if (r && r.missing_qty > 0) line += ' · <b style="color:var(--warn)">manque ' + esc(qty(r.missing_qty, item.unit)) + '</b>';
    if (r && r.surplus_qty > 0) line += ' · <b style="color:var(--info)">surplus ' + esc(qty(r.surplus_qty, item.unit)) + '</b>';
    line += '</span>';
    const extra = [];
    if (rep && rep.status === 'open') extra.push('<span class="meta">Motif : ' + esc(rep.reason) + '</span>');
    if (r && r.manager_instruction && ['to_fix', 'partial'].includes(st)) extra.push('<span class="meta" style="color:var(--violet);font-weight:700">Consigne : ' + esc(r.manager_instruction) + '</span>');
    if (item.comment) extra.push('<span class="meta">' + esc(item.comment) + '</span>');
    return '<button class="row" data-act="openItem" data-id="' + esc(item.id) + '"><span class="stripe" style="background:' + color + '"></span><span class="main"><span class="title">' + esc(item.product) + '</span>' + line + extra.join('') + '</span>' + pill(st) + '</button>';
  }

  function listDetail(id, manager) {
    const list = S.idx.list[id];
    if (!list) return '<a class="back" href="#/' + (manager ? 'lists' : 'today') + '">' + ICON.back + 'Retour</a><div class="panel empty"><h2>Liste introuvable</h2><p>Elle a peut-être été dépubliée ou supprimée.</p></div>';
    const t = typeOf(list); const s = summaryOf(id); const items = S.idx.itemsByList[id] || [];
    const late = L.isOverdue(list, s.remaining, new Date());
    const head =
      '<a class="back" href="#/' + (manager ? 'lists' : 'today') + '">' + ICON.back + 'Retour</a>' +
      '<div class="head"><div><h1>' + esc(list.name) + '</h1><p class="sub"><span class="swatch" style="background:' + esc(t.color) + '"></span>' + esc(t.name) + ' · ' + esc(fmtDate(list.work_date)) + ' · ' + esc(PERIOD[list.period]) + (list.due_time ? ' · avant ' + esc(list.due_time.slice(0, 5)) : '') + '</p></div>' +
      (manager ? '<span>' + listStatusPill(list.status) + '</span>' : '') + '</div>';
    const prog =
      '<div class="panel"><div class="head"><b class="num">' + s.done + ' sur ' + s.total + ' terminées</b>' + (late ? '<span class="pill" style="background:var(--bad-soft);color:var(--bad)">En retard</span>' : '') + '</div>' +
      '<div class="stackbar" aria-hidden="true">' + L.STATUS_ORDER.map((k) => (s[k] ? '<span style="flex:' + s[k] + ';background:' + L.STATUS[k].color + '"></span>' : '')).join('') + '</div></div>';
    const instr = list.instructions ? '<div class="banner info"><div><b>Consigne du management</b><br>' + esc(list.instructions).replace(/\n/g, '<br>') + '</div></div>' : '';
    const closed = list.status !== 'published' && !manager ? '<div class="banner warn">Cette liste n’est plus ouverte à la saisie.</div>' : '';
    const mgr = manager && App.managerListActions ? App.managerListActions(list, s) : '';
    return head + mgr + instr + closed + prog + '<div class="stack">' + items.map((i) => itemRow(i, list, manager)).join('') + '</div>';
  }

  // ---- feuille de saisie d'une quantité (employé) ou de consultation (manager)
  App.openItemSheet = function (itemId) {
    const item = S.idx.item[itemId]; if (!item) return;
    const list = S.idx.list[item.list_id]; const r = S.idx.result[itemId] || null; const st = r ? r.status : 'todo';
    const t = typeOf(list);
    const canInput = !isManager() && list.status === 'published' && L.canSubmitFrom(st);
    const head = '<div><h2>' + esc(item.product) + '</h2><p class="muted">' + esc(list.name) + (t.name !== list.name ? ' · ' + esc(t.name) : '') + '</p></div>';
    const instr = r && r.manager_instruction ? '<div class="banner violet"><div><b>Consigne du management</b><br>' + esc(r.manager_instruction) + '</div></div>' : '';
    const asked = '<div><p class="muted small">Quantité demandée</p><div class="big-qty num">' + esc(L.fmtQty(item.requested_qty)) + '<small>' + esc(item.unit) + '</small></div>' + (item.comment ? '<p class="muted" style="margin-top:6px">' + esc(item.comment) + '</p>' : '') + '</div>';

    if (!canInput) { App.openReadSheet(item, list, r, head, asked, instr); return; }

    const step = ['g', 'ml'].includes(item.unit) ? 50 : ['kg', 'L'].includes(item.unit) ? 0.5 : 1;
    const startVal = r && r.prepared_qty != null && st !== 'to_fix' ? L.fmtQty(r.prepared_qty) : '';
    const d = openSheet(head + asked + instr +
      '<div class="gauge" id="gauge" aria-hidden="true"><span class="fill" style="width:0%"></span><span class="mark" style="left:100%"></span></div>' +
      '<div class="field"><span>Quantité réellement préparée</span><div class="stepper"><button type="button" data-step="-1" aria-label="Moins">−</button>' +
      '<input id="qty" type="text" inputmode="decimal" autocomplete="off" value="' + esc(startVal) + '" aria-label="Quantité préparée en ' + esc(item.unit) + '" autofocus><button type="button" data-step="1" aria-label="Plus">+</button></div>' +
      '<button type="button" class="btn" id="fillAll">Tout est prêt : ' + esc(qty(item.requested_qty, item.unit)) + '</button></div>' +
      '<div id="verdict" aria-live="polite"></div>' +
      '<div id="reasonBlock" class="field hidden"><span>Pourquoi manque-t-il de la quantité ?</span><div class="chips" role="group" aria-label="Raison">' +
      L.REASONS.map((x) => '<button type="button" class="chip" data-reason="' + esc(x) + '" aria-pressed="false">' + esc(x) + '</button>').join('') + '</div></div>' +
      '<label id="commentBlock" class="field hidden"><span id="commentLabel">Commentaire</span><textarea id="comment" rows="3" maxlength="400"></textarea></label>' +
      '<p class="error" id="sheetError" role="alert"></p>' +
      '<div class="btn-row">' + (st === 'todo' ? '<button type="button" class="btn" id="startBtn">J’ai commencé</button>' : '') +
      '<button type="button" class="btn" data-act="closeSheet">Annuler</button><button type="button" class="btn primary" id="submitBtn" disabled style="flex:1">Valider</button></div>');

    const els = { qty: $('#qty', d), gauge: $('#gauge', d), verdict: $('#verdict', d), reasonBlock: $('#reasonBlock', d), commentBlock: $('#commentBlock', d), commentLabel: $('#commentLabel', d), comment: $('#comment', d), error: $('#sheetError', d), submit: $('#submitBtn', d) };
    let reason = '';

    function refresh() {
      const raw = els.qty.value;
      const c = L.compare(item.requested_qty, raw);
      const ev = L.evaluateSubmission({ requested: item.requested_qty, prepared: raw, reason, comment: els.comment.value, surplusPolicy: list.surplus_policy });
      // jauge
      const fill = $('.fill', els.gauge); const mark = $('.mark', els.gauge);
      const p = c.kind === 'invalid' ? 0 : c.prepared; const max = Math.max(item.requested_qty, p) || 1;
      fill.style.width = (p / max * 100) + '%'; mark.style.left = (item.requested_qty / max * 100) + '%';
      fill.className = 'fill' + (c.kind === 'equal' ? ' ok' : c.kind === 'shortfall' ? ' low' : c.kind === 'surplus' ? ' over' : '');
      // verdict
      if (c.kind === 'equal') els.verdict.innerHTML = '<div class="verdict ok"><span class="big">Quantité complète</span><span>Tu peux valider.</span></div>';
      else if (c.kind === 'shortfall') els.verdict.innerHTML = '<div class="verdict low"><span>Quantité insuffisante</span><span class="big num">Manque ' + esc(qty(-c.diff, item.unit)) + '</span><span>Demandé ' + esc(qty(c.requested, item.unit)) + ' · Préparé ' + esc(qty(c.prepared, item.unit)) + '</span></div>';
      else if (c.kind === 'surplus') els.verdict.innerHTML = '<div class="verdict over"><span>Plus que la demande</span><span class="big num">Surplus de ' + esc(qty(c.diff, item.unit)) + '</span></div>';
      else els.verdict.innerHTML = '';
      // raison et commentaire
      els.reasonBlock.classList.toggle('hidden', c.kind !== 'shortfall');
      const needsComment = (c.kind === 'shortfall') || (c.kind === 'surplus');
      els.commentBlock.classList.toggle('hidden', !needsComment);
      if (c.kind === 'shortfall') els.commentLabel.textContent = reason === L.OTHER_REASON ? 'Explique la raison (obligatoire)' : 'Commentaire (facultatif)';
      if (c.kind === 'surplus') els.commentLabel.textContent = list.surplus_policy === 'justify' ? 'Pourquoi plus que demandé ? (obligatoire)' : 'Commentaire (facultatif)';
      $$('.chip', d).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.reason === reason)));
      // bouton
      els.submit.disabled = !ev.ok;
      els.submit.className = 'btn ' + (c.kind === 'shortfall' ? 'warn' : c.kind === 'equal' ? 'go' : 'primary');
      els.submit.textContent = c.kind === 'shortfall' ? 'Envoyer au management' : c.kind === 'surplus' ? 'Valider avec surplus' : 'Valider';
      els.error.textContent = raw.trim() && !ev.ok ? ev.error : '';
      els.error.style.color = c.kind === 'invalid' ? 'var(--bad)' : 'var(--muted)';
      return ev;
    }
    els.qty.addEventListener('input', refresh);
    els.comment.addEventListener('input', refresh);
    $$('[data-step]', d).forEach((b) => b.addEventListener('click', () => {
      const cur = L.parseQty(els.qty.value); const base = Number.isNaN(cur) ? 0 : cur;
      els.qty.value = L.fmtQty(Math.max(0, Math.round((base + Number(b.dataset.step) * step) * 1000) / 1000)); refresh();
    }));
    $('#fillAll', d).addEventListener('click', () => { els.qty.value = L.fmtQty(item.requested_qty); refresh(); });
    $$('.chip', d).forEach((b) => b.addEventListener('click', () => { reason = b.dataset.reason; refresh(); if (reason === L.OTHER_REASON) els.comment.focus(); }));
    const startBtn = $('#startBtn', d);
    if (startBtn) startBtn.addEventListener('click', async () => {
      startBtn.disabled = true;
      try { await Backend.startItem(itemId); closeSheet(); toast('Marqué « en cours ».'); await reload(true); } catch (err) { toast(err.message, 'bad'); startBtn.disabled = false; }
    });
    els.submit.addEventListener('click', async () => {
      const ev = refresh(); if (!ev.ok) return;
      els.submit.disabled = true; els.submit.textContent = 'Envoi…';
      try {
        await Backend.submitResult(itemId, els.qty.value, reason, els.comment.value);
        closeSheet();
        toast(ev.status === 'partial' ? 'Écart signalé au management : ' + qty(ev.missing, item.unit) + ' manquants.' : item.product + ' validé.', ev.status === 'partial' ? '' : 'good');
        await reload(true);
      } catch (err) { els.error.textContent = err.message; els.error.style.color = 'var(--bad)'; refresh(); }
    });
    refresh();
  };

  // Consultation d'une ligne (déjà validée, ou vue du management)
  App.openReadSheet = function (item, list, r, head, asked, instr) {
    const st = r ? r.status : 'todo'; const rep = S.idx.reportByItem[item.id];
    let body = head + asked + instr + '<div>' + pill(st) + '</div>';
    if (r && r.prepared_qty != null) {
      body += '<div class="panel"><div class="grid2"><div><p class="muted small">Préparé</p><b class="num" style="font-size:1.4rem">' + esc(qty(r.prepared_qty, item.unit)) + '</b></div>' +
        (r.missing_qty > 0 ? '<div><p class="muted small">Manquant</p><b class="num" style="font-size:1.4rem;color:var(--warn)">' + esc(qty(r.missing_qty, item.unit)) + '</b></div>' : '') +
        (r.surplus_qty > 0 ? '<div><p class="muted small">Surplus</p><b class="num" style="font-size:1.4rem;color:var(--info)">' + esc(qty(r.surplus_qty, item.unit)) + '</b></div>' : '') + '</div>' +
        '<p class="muted small">' + esc((r.completed_by_name || r.updated_by_name || '') + (r.updated_at ? ' · ' + fmtDateTime(r.completed_at || r.updated_at) : '')) + '</p>' +
        (r.comment ? '<p>« ' + esc(r.comment) + ' »</p>' : '') + '</div>';
    }
    if (rep) {
      body += '<div class="panel"><h3>Signalement ' + (rep.status === 'open' ? 'en attente' : 'clos') + '</h3><p>Motif : <b>' + esc(rep.reason) + '</b>' + (rep.comment ? ' — ' + esc(rep.comment) : '') + '</p><p class="muted small">Par ' + esc(rep.reported_by_name || '') + ' · ' + esc(fmtDateTime(rep.reported_at)) + '</p>' +
        (rep.decision && rep.decision !== 'completed' ? '<p class="small"><b>' + esc((L.DECISIONS[rep.decision] || {}).label || rep.decision) + '</b>' + (rep.decision_note ? ' : ' + esc(rep.decision_note) : '') + (rep.decided_by_name ? ' — ' + esc(rep.decided_by_name) : '') + '</p>' : '') + '</div>';
    }
    if (!isManager()) {
      if (['done', 'gap_accepted'].includes(st)) body += '<p class="muted small">Cette ligne est validée. Seul un manager peut la rouvrir.</p>';
      else if (list.status !== 'published') body += '<p class="muted small">Cette liste n’est plus ouverte à la saisie.</p>';
    }
    const actions = isManager() && App.managerItemActions ? App.managerItemActions(item, list, r, rep) : '';
    openSheet(body + '<div class="btn-row">' + actions + '<button class="btn" data-act="closeSheet">Fermer</button></div>');
  };

  // ---- mes signalements
  App.views.e_mine = function () {
    const mine = S.data.reports.slice().sort((a, b) => (a.reported_at < b.reported_at ? 1 : -1));
    const label = (rep) => {
      if (rep.status === 'open' && ['complete', 'recheck'].includes(rep.decision)) return pill('to_fix');
      if (rep.status === 'open') return pill('partial');
      if (rep.decision === 'completed') return pill('done');
      return pill('gap_accepted');
    };
    return '<div class="head"><div><h1>Mes signalements</h1><p class="sub">Les écarts que tu as transmis au management.</p></div></div>' +
      (mine.length ? '<div class="stack">' + mine.map((rep) => {
        const item = S.idx.item[rep.item_id]; const list = S.idx.list[rep.list_id];
        return '<div class="panel"><div class="head"><h3>' + esc(item ? item.product : 'Produit') + '</h3>' + label(rep) + '</div>' +
          '<p class="muted small">' + esc(list ? list.name + ' · ' : '') + esc(fmtDateTime(rep.reported_at)) + '</p>' +
          '<p>Demandé ' + esc(qty(rep.requested_qty, item && item.unit)) + ' · Préparé ' + esc(qty(rep.prepared_qty, item && item.unit)) + ' · <b>manque ' + esc(qty(rep.missing_qty, item && item.unit)) + '</b></p>' +
          '<p>Motif : ' + esc(rep.reason) + (rep.comment ? ' — ' + esc(rep.comment) : '') + '</p>' +
          (rep.decision && rep.decision !== 'completed' ? '<div class="banner violet"><div><b>' + esc((L.DECISIONS[rep.decision] || {}).label || '') + '</b>' + (rep.decision_note ? '<br>' + esc(rep.decision_note) : '') + '</div></div>' : '') + '</div>';
      }).join('') + '</div>' : '<div class="panel empty"><h2>Aucun signalement</h2><p>Quand une quantité préparée est inférieure à la demande, ton signalement apparaît ici.</p></div>');
  };

  // ---------------------------------------------------------------- démarrage
  App.describeEvent = null; // défini dans app-manager.js
  (async function boot() {
    try {
      S.user = await Backend.init();
      if (S.user) await start(); else render();
    } catch (err) {
      $('#app').innerHTML = '<div class="login"><div class="card"><h1>Démarrage impossible</h1><p class="error">' + esc(err.message) + '</p><button class="btn primary" onclick="location.reload()">Réessayer</button></div></div>';
    }
  })();
})();
