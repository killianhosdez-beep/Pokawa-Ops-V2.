/* Pokawa Ops — espace management : tableau de bord, signalements, listes, historique, équipe, réglages. */
(function () {
  'use strict';
  const App = window.App;
  const { L, S, ui, esc, $, $$, qty, today, shiftDate, fmtDate, fmtDateShort, fmtTime, fmtDateTime, ROLE, PERIOD, ICON, pill, listStatusPill, toast, openSheet, closeSheet, confirmBox, Backend } = App;
  const type = (list) => S.idx.type[list.type_id] || { name: 'Liste', color: '#0B2F45' };

  const dateNav = (key, date) =>
    '<div class="btn-row" style="align-items:center"><button class="btn sm" data-act="dateShift" data-key="' + key + '" data-d="-1" aria-label="Jour précédent">‹</button>' +
    '<input type="date" value="' + esc(date) + '" data-change="dateSet" data-key="' + key + '" style="width:auto" aria-label="Date">' +
    '<button class="btn sm" data-act="dateShift" data-key="' + key + '" data-d="1" aria-label="Jour suivant">›</button>' +
    '<button class="btn sm" data-act="dateShift" data-key="' + key + '" data-d="0">Aujourd’hui</button></div>';
  App.acts.dateShift = (el) => { const k = el.dataset.key; ui[k] = el.dataset.d === '0' ? today() : shiftDate(ui[k] || today(), Number(el.dataset.d)); App.$('#app') && rerender(); };
  App.acts.dateSet = (el) => { if (el.value) { ui[el.dataset.key] = el.value; rerender(); } };
  const rerender = () => { App.pendingRender = false; window.dispatchEvent(new HashChangeEvent('hashchange')); };

  function statBar(s) {
    return '<div class="stackbar" aria-hidden="true">' + L.STATUS_ORDER.map((k) => (s[k] ? '<span style="flex:' + s[k] + ';background:' + L.STATUS[k].color + '"></span>' : '')).join('') + '</div>' +
      '<div class="counts">' + L.STATUS_ORDER.filter((k) => s[k]).map((k) => '<span><i class="dot" style="background:' + L.STATUS[k].color + '"></i><b>' + s[k] + '</b> ' + esc(L.STATUS[k].short.toLowerCase()) + '</span>').join('') +
      (s.reports ? '<span><i class="dot" style="background:var(--bad)"></i><b>' + s.reports + '</b> signalement' + (s.reports > 1 ? 's' : '') + '</span>' : '') + '</div>';
  }

  // ---------------------------------------------------------------- événements lisibles (historique)
  function describeEvent(e) {
    const d = e.details || {}; const list = S.idx.list[e.list_id]; const ln = list ? list.name : d.name || '';
    const u = d.unit || '';
    switch (e.action) {
      case 'creation_liste': return 'Liste créée : ' + (d.name || ln);
      case 'publication': return 'Liste publiée : ' + (d.name || ln);
      case 'depublication': return 'Liste repassée en brouillon : ' + (d.name || ln);
      case 'cloture': return 'Liste clôturée : ' + (d.name || ln);
      case 'duplication': return 'Liste dupliquée : ' + (d.name || ln);
      case 'modification_apres_publication':
        if (d.operation === 'UPDATE') return 'Modifié après publication — ' + d.product + ' : ' + (d.old_qty != null ? L.fmtQty(Number(d.old_qty)) : '?') + ' → ' + (d.new_qty != null ? L.fmtQty(Number(d.new_qty)) : '?') + ' ' + u + ' (' + ln + ')';
        if (d.operation === 'INSERT') return 'Ajouté après publication — ' + d.product + ' ' + L.fmtQty(Number(d.new_qty)) + ' ' + u + ' (' + ln + ')';
        if (d.operation === 'DELETE') return 'Retiré après publication — ' + d.product + ' (' + ln + ')';
        return 'Liste modifiée après publication : ' + ln;
      case 'demarrage': return d.product + ' : commencé';
      case 'validation': return d.product + ' validé — ' + L.fmtQty(Number(d.prepared)) + ' ' + u + ' (demandé ' + L.fmtQty(Number(d.requested)) + ')';
      case 'validation_surplus': return d.product + ' validé avec surplus — ' + L.fmtQty(Number(d.prepared)) + ' ' + u + ' (demandé ' + L.fmtQty(Number(d.requested)) + ')' + (d.comment ? ' · ' + d.comment : '');
      case 'validation_partielle': return d.product + ' : production partielle — ' + L.fmtQty(Number(d.prepared)) + '/' + L.fmtQty(Number(d.requested)) + ' ' + u + ', manque ' + L.fmtQty(Number(d.missing)) + ' · ' + d.reason + (d.comment ? ' (' + d.comment + ')' : '');
      case 'reouverture': return d.product + ' rouvert' + (d.note ? ' : ' + d.note : '');
      case 'compte_cree': return 'Compte créé : ' + d.name + ' (' + (ROLE[d.role] || d.role) + ')';
      case 'compte_modifie': return 'Compte modifié : ' + d.name + ' — ' + (ROLE[d.role] || d.role) + (d.active === false ? ', désactivé' : '');
      case 'mot_de_passe_reinitialise': return 'Mot de passe réinitialisé';
      case 'type_modifie': return 'Type de liste enregistré : ' + (d.name || '');
      default:
        if (e.action.startsWith('decision_')) return 'Décision « ' + ((L.DECISIONS[e.action.slice(9)] || {}).label || e.action) + ' » sur ' + (d.product || 'une ligne') + (d.note ? ' : ' + d.note : '');
        return e.action;
    }
  }
  App.describeEvent = describeEvent;

  // ================================================================ TABLEAU DE BORD
  App.views.m_dash = function () {
    const date = ui.dashDate || today();
    const lists = S.data.lists.filter((l) => l.work_date === date && l.status !== 'draft').sort((a, b) => String(a.due_time || '99').localeCompare(String(b.due_time || '99')));
    const drafts = S.data.lists.filter((l) => l.work_date === date && l.status === 'draft').length;
    const sums = lists.map((l) => ({ l, s: App.summaryOf(l.id) }));
    const remaining = sums.reduce((n, x) => n + (x.l.status === 'published' ? x.s.remaining : 0), 0);
    const lateLists = S.data.lists.filter((l) => l.status === 'published' && L.isOverdue(l, App.summaryOf(l.id).remaining, new Date()));
    const open = S.idx.openReports;

    // alertes
    const alerts = [];
    if (open.length) alerts.push(['bad', '<a href="#/reports"><b>' + open.length + ' signalement' + (open.length > 1 ? 's attendent' : ' attend') + ' une décision</b></a>']);
    lateLists.forEach((l) => alerts.push(['bad', '<a href="#/list/' + esc(l.id) + '"><b>' + esc(l.name) + '</b> est en retard' + (l.due_time ? ' (avant ' + esc(l.due_time.slice(0, 5)) + ')' : '') + ' — ' + App.summaryOf(l.id).remaining + ' ligne(s) restante(s)</a>']));
    const dayAgo = Date.now() - 24 * 3600 * 1000;
    const mods = {};
    S.data.audit.filter((e) => e.action === 'modification_apres_publication' && new Date(e.at).getTime() > dayAgo && S.idx.list[e.list_id]).forEach((e) => { (mods[e.list_id] = mods[e.list_id] || []).push(e); });
    Object.keys(mods).forEach((id) => alerts.push(['warn', '<a href="#/list/' + esc(id) + '"><b>' + esc(S.idx.list[id].name) + '</b> modifiée après publication (' + mods[id].length + ' changement' + (mods[id].length > 1 ? 's' : '') + ', dernier à ' + esc(fmtTime(mods[id][0].at)) + ' par ' + esc(mods[id][0].actor_name || '?') + ')</a>']));
    S.data.audit.filter((e) => e.action === 'publication' && new Date(e.at).getTime() > Date.now() - 3 * 3600 * 1000).slice(0, 2).forEach((e) => alerts.push(['info', 'Liste publiée à ' + esc(fmtTime(e.at)) + ' : <b>' + esc((e.details && e.details.name) || '') + '</b>']));

    const tiles =
      '<div class="tiles"><div class="tile"><span class="muted small">Listes ouvertes</span><b>' + lists.filter((l) => l.status === 'published').length + '</b></div>' +
      '<div class="tile"><span class="muted small">Lignes restantes</span><b>' + remaining + '</b></div>' +
      '<div class="tile' + (open.length ? ' alert' : '') + '"><span class="muted small">À décider</span><b>' + open.length + '</b></div>' +
      '<div class="tile' + (lateLists.length ? ' alert' : '') + '"><span class="muted small">Listes en retard</span><b>' + lateLists.length + '</b></div></div>';

    return '<div class="head"><div><h1>Tableau de bord</h1><p class="sub">' + esc(fmtDate(date)) + '</p></div>' + dateNav('dashDate', date) + '</div>' + tiles +
      (alerts.length ? '<div class="panel"><h2>À surveiller</h2><div class="stack">' + alerts.slice(0, 8).map((a) => '<div class="banner ' + a[0] + '"><div>' + a[1] + '</div></div>').join('') + '</div></div>' : '') +
      '<div class="head"><h2>Avancement des listes</h2><a class="btn sm primary" href="#/lists">Gérer les listes</a></div>' +
      (sums.length ? '<div class="stack">' + sums.map(({ l, s }) => {
        const t = type(l); const late = L.isOverdue(l, s.remaining, new Date());
        return '<a class="row" href="#/list/' + esc(l.id) + '" style="grid-template-columns:6px 1fr auto"><span class="stripe" style="background:' + esc(t.color) + '"></span><span class="main">' +
          '<span class="title">' + esc(l.name) + ' ' + (l.status === 'closed' ? listStatusPill('closed') : '') + (late ? ' <span class="pill" style="background:var(--bad-soft);color:var(--bad)">En retard</span>' : '') + '</span>' +
          '<span class="meta">' + (t.name !== l.name ? esc(t.name) : esc(PERIOD[l.period])) + (l.due_time ? ' · avant ' + esc(l.due_time.slice(0, 5)) : '') + ' · <b class="num">' + s.total + '</b> tâches à réaliser, <b class="num">' + s.done + '</b> terminées</span>' + statBar(s) + '</span>' + ICON.chev + '</a>';
      }).join('') + '</div>'
        : '<div class="panel empty"><h2>Aucune liste publiée ce jour</h2><p>' + (drafts ? drafts + ' brouillon' + (drafts > 1 ? 's' : '') + ' en préparation. ' : '') + 'Crée une liste ou publie un brouillon pour que l’équipe la voie.</p><button class="btn primary" data-act="newList">Nouvelle liste</button></div>');
  };

  // ================================================================ SIGNALEMENTS
  function reportCard(rep, withAction) {
    const item = S.idx.item[rep.item_id]; const list = S.idx.list[rep.list_id]; const u = item && item.unit;
    const dec = rep.decision && rep.decision !== 'completed' ? '<div class="banner violet"><div><b>' + esc((L.DECISIONS[rep.decision] || {}).label || '') + '</b>' + (rep.decision_note ? ' : ' + esc(rep.decision_note) : '') + (rep.decided_by_name ? '<br><span class="small">' + esc(rep.decided_by_name) + ' · ' + esc(fmtDateTime(rep.decided_at)) + '</span>' : '') + '</div></div>' : '';
    return '<div class="panel"><div class="head"><div><h3>' + esc(item ? item.product : 'Produit') + '</h3><p class="muted small">' + esc(list ? list.name : '') + (list ? ' · ' + esc(fmtDateShort(list.work_date)) : '') + '</p></div>' +
      (rep.status === 'open' ? pill(['complete', 'recheck'].includes(rep.decision) ? 'to_fix' : 'partial') : pill(rep.decision === 'completed' ? 'done' : 'gap_accepted')) + '</div>' +
      '<div class="grid2"><div><p class="muted small">Demandé</p><b class="num">' + esc(qty(rep.requested_qty, u)) + '</b></div><div><p class="muted small">Préparé</p><b class="num">' + esc(qty(rep.prepared_qty, u)) + '</b></div><div><p class="muted small">Manquant</p><b class="num" style="color:var(--warn)">' + esc(qty(rep.missing_qty, u)) + '</b></div></div>' +
      '<p>Motif : <b>' + esc(rep.reason) + '</b>' + (rep.comment ? ' — ' + esc(rep.comment) : '') + '</p>' +
      '<p class="muted small">Signalé par ' + esc(rep.reported_by_name || '?') + ' · ' + esc(fmtDateTime(rep.reported_at)) + '</p>' + dec +
      (withAction ? '<div class="btn-row"><button class="btn primary" data-act="openDecision" data-id="' + esc(rep.id) + '">Décider</button>' + (list ? '<a class="btn" href="#/list/' + esc(list.id) + '">Voir la liste</a>' : '') + '</div>' : '') + '</div>';
  }
  App.views.m_reports = function () {
    const open = S.idx.openReports;
    const done = S.data.reports.filter((r) => r.status === 'resolved' && r.decision !== 'completed').sort((a, b) => (a.decided_at < b.decided_at ? 1 : -1)).slice(0, 15);
    return '<div class="head"><div><h1>Signalements</h1><p class="sub">Écarts entre la quantité demandée et la quantité préparée.</p></div></div>' +
      '<h2>À décider (' + open.length + ')</h2>' +
      (open.length ? '<div class="stack">' + open.map((r) => reportCard(r, true)).join('') + '</div>' : '<div class="panel empty"><h3>Rien à décider</h3><p>Tous les signalements ont été traités.</p></div>') +
      (done.length ? '<h2>Décisions récentes</h2><div class="stack">' + done.map((r) => reportCard(r, false)).join('') + '</div>' : '');
  };

  App.acts.openDecision = (el) => {
    const rep = S.data.reports.find((r) => r.id === el.dataset.id); if (!rep) return;
    const item = S.idx.item[rep.item_id];
    openSheet('<div><h2>' + esc(item ? item.product : 'Signalement') + '</h2><p class="muted">Manque ' + esc(qty(rep.missing_qty, item && item.unit)) + ' · ' + esc(rep.reason) + (rep.comment ? ' — ' + esc(rep.comment) : '') + '</p></div>' +
      '<form data-form="decide" data-id="' + esc(rep.id) + '" class="stack"><div class="field"><span>Que décides-tu ?</span><div class="chips" role="radiogroup">' +
      Object.entries(L.DECISIONS).map(([k, d], i) => '<label class="chip" style="display:flex;gap:10px;align-items:center"><input type="radio" name="decision" value="' + k + '" ' + (i === 0 ? 'checked' : '') + ' style="width:22px;min-height:22px"> ' + esc(d.label) + '</label>').join('') + '</div></div>' +
      '<label class="field"><span id="noteLabel">Consigne pour l’équipe (facultatif)</span><textarea name="note" rows="3" maxlength="400"></textarea></label>' +
      '<div class="banner info"><div>Accepter un écart ne rend jamais la production « terminée » : elle reste marquée comme écart accepté dans l’historique.</div></div>' +
      '<p class="error" id="decideError" role="alert"></p><div class="btn-row"><button type="button" class="btn" data-act="closeSheet">Annuler</button><button class="btn primary" type="submit" style="flex:1">Enregistrer la décision</button></div></form>');
    const f = $('#sheet form'); const upd = () => { const v = f.decision.value; $('#noteLabel').textContent = L.DECISIONS[v].noteRequired ? 'Justification ou consigne (obligatoire)' : 'Consigne pour l’équipe (facultatif)'; };
    f.addEventListener('change', upd); upd();
  };
  App.acts.form_decide = async (f) => {
    const btn = $('[type=submit]', f); btn.disabled = true;
    try { await Backend.decideReport(f.dataset.id, f.decision.value, f.note.value); closeSheet(); toast('Décision enregistrée.', 'good'); await App.reload(true); }
    catch (err) { $('#decideError').textContent = err.message; btn.disabled = false; }
  };

  // ================================================================ LISTES
  App.views.m_lists = function () {
    const date = ui.listsDate || today();
    const lists = S.data.lists.filter((l) => l.work_date === date).sort((a, b) => String(a.due_time || '99').localeCompare(String(b.due_time || '99')));
    return '<div class="head"><div><h1>Listes</h1><p class="sub">' + esc(fmtDate(date)) + '</p></div><button class="btn primary" data-act="newList">Nouvelle liste</button></div>' + dateNav('listsDate', date) +
      (lists.length ? '<div class="stack">' + lists.map((l) => {
        const s = App.summaryOf(l.id); const t = type(l);
        return '<a class="row" href="#/list/' + esc(l.id) + '"><span class="stripe" style="background:' + esc(t.color) + '"></span><span class="main"><span class="title">' + esc(l.name) + ' ' + listStatusPill(l.status) + '</span>' +
          '<span class="meta">' + esc(t.name) + ' · ' + esc(PERIOD[l.period]) + (l.due_time ? ' · avant ' + esc(l.due_time.slice(0, 5)) : '') + ' · ' + s.total + ' produit' + (s.total > 1 ? 's' : '') + (l.status !== 'draft' ? ' · ' + s.done + ' terminés' : '') + '</span></span>' + ICON.chev + '</a>';
      }).join('') + '</div>'
        : '<div class="panel empty"><h2>Aucune liste ce jour</h2><p>Crée une liste, ou duplique celle d’un autre jour depuis son écran.</p><button class="btn primary" data-act="newList">Nouvelle liste</button></div>');
  };

  App.managerListActions = function (list, s) {
    const b = [];
    b.push('<button class="btn" data-act="editList" data-id="' + esc(list.id) + '">Modifier</button>');
    if (list.status === 'draft') b.push('<button class="btn primary" data-act="listStatus" data-id="' + esc(list.id) + '" data-s="published">Publier</button>');
    if (list.status === 'published') {
      b.push('<button class="btn" data-act="listStatus" data-id="' + esc(list.id) + '" data-s="closed">Clôturer</button>');
      b.push('<button class="btn" data-act="listStatus" data-id="' + esc(list.id) + '" data-s="draft">Dépublier</button>');
    }
    if (list.status === 'closed') b.push('<button class="btn" data-act="listStatus" data-id="' + esc(list.id) + '" data-s="published">Rouvrir la liste</button>');
    b.push('<button class="btn" data-act="duplicateList" data-id="' + esc(list.id) + '">Dupliquer</button>');
    const note = list.status === 'draft' ? '<div class="banner warn">Brouillon : les employés ne voient pas cette liste tant qu’elle n’est pas publiée.</div>' : '';
    return '<div class="btn-row">' + b.join('') + '</div>' + note;
  };
  App.acts.listStatus = async (el) => {
    const s = el.dataset.s; const list = S.idx.list[el.dataset.id];
    const msg = { published: 'Les employés verront cette liste immédiatement.', closed: 'Plus aucune saisie ne sera possible. L’historique est conservé.', draft: 'Les employés ne verront plus cette liste.' }[s];
    if (!(await confirmBox(msg, { title: { published: 'Publier « ' + list.name + ' » ?', closed: 'Clôturer « ' + list.name + ' » ?', draft: 'Dépublier « ' + list.name + ' » ?' }[s], ok: { published: 'Publier', closed: 'Clôturer', draft: 'Dépublier' }[s] }))) return;
    await Backend.setListStatus(list.id, s); toast({ published: 'Liste publiée.', closed: 'Liste clôturée.', draft: 'Liste repassée en brouillon.' }[s], 'good'); await App.reload(true);
  };
  App.acts.duplicateList = (el) => {
    const list = S.idx.list[el.dataset.id];
    openSheet('<div><h2>Dupliquer « ' + esc(list.name) + ' »</h2><p class="muted">La copie est créée en brouillon, sans aucune quantité préparée.</p></div>' +
      '<form data-form="duplicate" data-id="' + esc(list.id) + '" class="stack"><label class="field"><span>Pour quel jour ?</span><input type="date" name="date" value="' + esc(shiftDate(list.work_date > today() ? list.work_date : today(), list.work_date >= today() ? 1 : 0)) + '" required></label><p class="error" id="dupError"></p>' +
      '<div class="btn-row"><button type="button" class="btn" data-act="closeSheet">Annuler</button><button class="btn primary" type="submit" style="flex:1">Dupliquer</button></div></form>');
  };
  App.acts.form_duplicate = async (f) => {
    try { const id = await Backend.duplicateList(f.dataset.id, f.date.value); closeSheet(); toast('Copie créée en brouillon.', 'good'); await App.reload(true); App.go('list/' + id); }
    catch (err) { $('#dupError').textContent = err.message; }
  };

  App.managerItemActions = function (item, list, r, rep) {
    const out = [];
    if (rep && rep.status === 'open') out.push('<button class="btn primary" data-act="openDecision" data-id="' + esc(rep.id) + '">Traiter le signalement</button>');
    if (r && r.status !== 'todo' && list.status === 'published') out.push('<button class="btn" data-act="reopenItem" data-id="' + esc(item.id) + '">Rouvrir la ligne</button>');
    return out.join('');
  };
  App.acts.reopenItem = (el) => {
    const item = S.idx.item[el.dataset.id];
    openSheet('<div><h2>Rouvrir « ' + esc(item.product) + ' »</h2><p class="muted">La ligne repasse « à corriger » et l’employé peut renvoyer une quantité.</p></div>' +
      '<form data-form="reopen" data-id="' + esc(item.id) + '" class="stack"><label class="field"><span>Consigne pour l’équipe (facultatif)</span><textarea name="note" rows="3" maxlength="400" autofocus></textarea></label><p class="error" id="reopenError"></p>' +
      '<div class="btn-row"><button type="button" class="btn" data-act="closeSheet">Annuler</button><button class="btn primary" type="submit" style="flex:1">Rouvrir</button></div></form>');
  };
  App.acts.form_reopen = async (f) => {
    try { await Backend.reopenItem(f.dataset.id, f.note.value); closeSheet(); toast('Ligne rouverte.', 'good'); await App.reload(true); } catch (err) { $('#reopenError').textContent = err.message; }
  };

  // ---------------------------------------------------------------- éditeur de liste
  App.acts.newList = () => openListEditor(null);
  App.acts.editList = (el) => openListEditor(el.dataset.id);

  function openListEditor(listId) {
    const existing = listId ? S.idx.list[listId] : null;
    const types = S.data.types.filter((t) => t.active || (existing && existing.type_id === t.id));
    const base = existing || { id: null, name: '', type_id: (types[0] || {}).id, work_date: ui.listsDate || today(), period: 'morning', due_time: '', instructions: '', surplus_policy: 'justify', status: 'draft' };
    const st = { list: { ...base, due_time: base.due_time ? base.due_time.slice(0, 5) : '' }, items: [] };
    st.items = (existing ? (S.idx.itemsByList[existing.id] || []) : []).map((i) => ({ id: i.id, product: i.product, requested_qty: L.fmtQty(i.requested_qty), unit: i.unit, comment: i.comment || '', locked: App.statusOf(i.id) !== 'todo' }));
    if (!st.items.length) st.items.push({ product: '', requested_qty: '', unit: 'kg', comment: '' });
    const published = existing && existing.status === 'published';

    const products = {}; S.data.items.forEach((i) => { products[i.product.toLowerCase()] = { name: i.product, unit: i.unit }; });
    const dl = '<datalist id="dlProducts">' + Object.values(products).map((p) => '<option value="' + esc(p.name) + '">').join('') + '</datalist><datalist id="dlUnits">' + L.UNITS.map((u) => '<option value="' + esc(u) + '">').join('') + '</datalist>';

    const itemsHtml = () => st.items.map((it, i) =>
      '<div class="item-edit" data-i="' + i + '"><label class="field"><span class="' + (i ? 'sr' : '') + '">Produit</span><input type="text" data-f="product" list="dlProducts" value="' + esc(it.product) + '" placeholder="Ex. Riz" autocomplete="off"></label>' +
      '<label class="field"><span class="' + (i ? 'sr' : '') + '">Quantité</span><input type="text" inputmode="decimal" data-f="requested_qty" value="' + esc(it.requested_qty) + '" placeholder="12"></label>' +
      '<label class="field"><span class="' + (i ? 'sr' : '') + '">Unité</span><input type="text" data-f="unit" list="dlUnits" value="' + esc(it.unit) + '" placeholder="kg"></label>' +
      '<button type="button" class="del" data-del="' + i + '" aria-label="Retirer ' + esc(it.product || 'la ligne') + '" ' + (it.locked ? 'disabled title="Du travail est déjà enregistré sur cette ligne"' : '') + '>✕</button>' +
      '<label class="field full"><input type="text" data-f="comment" value="' + esc(it.comment) + '" placeholder="Commentaire facultatif (ex. bac gastro 1/1)" aria-label="Commentaire"></label>' +
      (it.locked ? '<p class="small muted full">Déjà renseigné par l’équipe : toute modification de quantité est tracée.</p>' : '') + '</div>').join('');

    const d = openSheet('<div><h2>' + (existing ? 'Modifier la liste' : 'Nouvelle liste') + '</h2></div>' + dl +
      (published ? '<div class="banner warn"><div><b>Liste publiée.</b> Les modifications sont visibles tout de suite par l’équipe et enregistrées dans l’historique.</div></div>' : '') +
      '<form id="listForm" class="stack" novalidate><div class="grid2"><label class="field" style="grid-column:1/-1"><span>Nom de la liste</span><input type="text" data-l="name" value="' + esc(st.list.name) + '" placeholder="Ex. Production du matin" autofocus></label>' +
      '<label class="field"><span>Type</span><select data-l="type_id">' + types.map((t) => '<option value="' + esc(t.id) + '" ' + (t.id === st.list.type_id ? 'selected' : '') + '>' + esc(t.name) + '</option>').join('') + '</select></label>' +
      '<label class="field"><span>Date</span><input type="date" data-l="work_date" value="' + esc(st.list.work_date) + '"></label>' +
      '<label class="field"><span>Période</span><select data-l="period">' + Object.entries(PERIOD).map(([k, v]) => '<option value="' + k + '" ' + (k === st.list.period ? 'selected' : '') + '>' + esc(v) + '</option>').join('') + '</select></label>' +
      '<label class="field"><span>À terminer avant</span><input type="time" data-l="due_time" value="' + esc(st.list.due_time) + '"></label>' +
      '<label class="field" style="grid-column:1/-1"><span>Si la quantité préparée dépasse la demande</span><select data-l="surplus_policy"><option value="justify" ' + (st.list.surplus_policy === 'justify' ? 'selected' : '') + '>Commentaire obligatoire</option><option value="allow" ' + (st.list.surplus_policy === 'allow' ? 'selected' : '') + '>Autorisé (signalé dans l’historique)</option></select></label></div>' +
      '<label class="field"><span>Consignes pour l’équipe</span><textarea data-l="instructions" rows="2" maxlength="600" placeholder="Facultatif">' + esc(st.list.instructions || '') + '</textarea></label>' +
      '<div><h3>Produits à préparer</h3><div id="items">' + itemsHtml() + '</div>' +
      '<div class="btn-row" style="margin-top:10px"><button type="button" class="btn sm" id="addItem">+ Ajouter un produit</button><button type="button" class="btn sm" id="bulkBtn">Coller plusieurs lignes</button></div>' +
      '<div id="bulk" class="field hidden" style="margin-top:10px"><span>Une ligne par produit : « Riz 12 kg », « Sauce fromagère; 4; L »</span><textarea id="bulkText" rows="5"></textarea><button type="button" class="btn sm" id="bulkAdd">Ajouter ces lignes</button></div></div>' +
      '<p class="error" id="editError" role="alert"></p>' +
      '<div class="btn-row"><button type="button" class="btn" data-act="closeSheet">Annuler</button>' +
      (published ? '<button type="submit" class="btn primary" data-after="save" style="flex:1">Enregistrer les modifications</button>' :
        '<button type="submit" class="btn" data-after="save">Enregistrer le brouillon</button><button type="submit" class="btn primary" data-after="publish" style="flex:1">Enregistrer et publier</button>') + '</div></form>', { wide: true });

    const itemsBox = $('#items', d);
    const redraw = () => { itemsBox.innerHTML = itemsHtml(); };
    d.addEventListener('input', (e) => {
      const l = e.target.dataset.l; if (l) { st.list[l] = e.target.value; return; }
      const row = e.target.closest('.item-edit'); if (!row || !e.target.dataset.f) return;
      const it = st.items[Number(row.dataset.i)]; it[e.target.dataset.f] = e.target.value;
      if (e.target.dataset.f === 'product') { const known = products[e.target.value.trim().toLowerCase()]; if (known && !it.unit.trim()) { it.unit = known.unit; $('[data-f=unit]', row).value = known.unit; } }
    });
    d.addEventListener('change', (e) => { const l = e.target.dataset.l; if (l) st.list[l] = e.target.value; });
    itemsBox.addEventListener('click', (e) => { const b = e.target.closest('[data-del]'); if (b && !b.disabled) { st.items.splice(Number(b.dataset.del), 1); if (!st.items.length) st.items.push({ product: '', requested_qty: '', unit: 'kg', comment: '' }); redraw(); } });
    $('#addItem', d).addEventListener('click', () => { const last = st.items[st.items.length - 1]; st.items.push({ product: '', requested_qty: '', unit: last ? last.unit : 'kg', comment: '' }); redraw(); const rows = $$('.item-edit', itemsBox); $('[data-f=product]', rows[rows.length - 1]).focus(); });
    $('#bulkBtn', d).addEventListener('click', () => { $('#bulk', d).classList.toggle('hidden'); $('#bulkText', d).focus(); });
    $('#bulkAdd', d).addEventListener('click', () => {
      const bad = [];
      $('#bulkText', d).value.split(/\n/).map((x) => x.trim()).filter(Boolean).forEach((line) => {
        const m = line.match(/^(.+?)\s*[;:\t]\s*(\d+(?:[.,]\d+)?)\s*[;:\t ]?\s*(\S.*)?$/) || line.match(/^(.+?)\s+(\d+(?:[.,]\d+)?)\s*(\S.*)?$/);
        if (!m) { bad.push(line); return; }
        const unit = (m[3] || (products[m[1].trim().toLowerCase()] || {}).unit || 'kg').trim();
        const blank = st.items.length === 1 && !st.items[0].product && !st.items[0].requested_qty;
        if (blank) st.items.pop();
        st.items.push({ product: m[1].trim(), requested_qty: m[2].replace('.', ','), unit, comment: '' });
      });
      redraw(); $('#bulkText', d).value = bad.join('\n');
      $('#editError', d).textContent = bad.length ? bad.length + ' ligne(s) non comprise(s), laissée(s) dans la zone pour correction.' : '';
      if (!bad.length) $('#bulk', d).classList.add('hidden');
    });

    let submitter = 'save';
    $$('[type=submit]', d).forEach((b) => b.addEventListener('click', () => { submitter = b.dataset.after; }));
    $('#listForm', d).addEventListener('submit', async (e) => {
      e.preventDefault();
      const btns = $$('[type=submit]', d); btns.forEach((b) => { b.disabled = true; });
      const err = $('#editError', d); err.textContent = '';
      try {
        const clean = st.items.filter((it) => it.product.trim() || String(it.requested_qty).trim());
        if (submitter === 'publish') {
          const ok = await confirmBox('Les employés verront cette liste immédiatement.', { title: 'Publier « ' + (st.list.name || 'la liste') + ' » ?', ok: 'Publier' });
          if (!ok) { btns.forEach((b) => { b.disabled = false; }); return; }
        }
        const id = await Backend.saveList({ ...st.list, id: existing ? existing.id : null }, clean);
        if (submitter === 'publish') await Backend.setListStatus(id, 'published');
        closeSheet(); toast(submitter === 'publish' ? 'Liste enregistrée et publiée.' : 'Liste enregistrée.', 'good');
        await App.reload(true); App.go('list/' + id);
      } catch (ex) { err.textContent = ex.message; btns.forEach((b) => { b.disabled = false; }); }
    });
  }

  // ================================================================ HISTORIQUE
  function histFilters() {
    if (!ui.hist) ui.hist = { from: shiftDate(today(), -13), to: today(), type: '', product: '', employee: '' };
    return ui.hist;
  }
  function filteredLists(h) {
    const prod = h.product.trim().toLowerCase(); const emp = h.employee.trim().toLowerCase();
    return S.data.lists.filter((l) => {
      if (l.status === 'draft' || l.work_date < h.from || l.work_date > h.to) return false;
      if (h.type && l.type_id !== h.type) return false;
      const items = S.idx.itemsByList[l.id] || [];
      if (prod && !items.some((i) => i.product.toLowerCase().includes(prod))) return false;
      if (emp) {
        const hit = items.some((i) => { const r = S.idx.result[i.id]; return r && ((r.completed_by_name || '').toLowerCase().includes(emp) || (r.updated_by_name || '').toLowerCase().includes(emp)); }) ||
          S.data.reports.some((r) => r.list_id === l.id && (r.reported_by_name || '').toLowerCase().includes(emp));
        if (!hit) return false;
      }
      return true;
    }).sort((a, b) => (a.work_date < b.work_date ? 1 : a.work_date > b.work_date ? -1 : String(a.due_time || '').localeCompare(String(b.due_time || ''))));
  }
  App.views.m_history = function (arg) {
    const h = histFilters();
    const filters = '<form class="panel" data-form="histFilter"><div class="grid2">' +
      '<label class="field"><span>Du</span><input type="date" name="from" value="' + esc(h.from) + '"></label><label class="field"><span>Au</span><input type="date" name="to" value="' + esc(h.to) + '"></label>' +
      '<label class="field"><span>Type de liste</span><select name="type"><option value="">Tous</option>' + S.data.types.map((t) => '<option value="' + esc(t.id) + '" ' + (h.type === t.id ? 'selected' : '') + '>' + esc(t.name) + '</option>').join('') + '</select></label>' +
      '<label class="field"><span>Produit</span><input type="search" name="product" value="' + esc(h.product) + '" placeholder="Ex. riz"></label>' +
      '<label class="field"><span>Employé</span><input type="search" name="employee" value="' + esc(h.employee) + '" placeholder="Ex. Emma"></label></div>' +
      '<div class="btn-row"><button class="btn primary sm" type="submit">Rechercher</button><button class="btn sm" type="button" data-act="histReset">Réinitialiser</button></div></form>';
    const tabs = '<div class="tabs" role="tablist"><button role="tab" data-act="histTab" data-t="lists" aria-selected="' + (ui.histTab === 'lists') + '">Listes et productions</button><button role="tab" data-act="histTab" data-t="journal" aria-selected="' + (ui.histTab === 'journal') + '">Journal des actions</button></div>';
    let body;
    if (ui.histTab === 'lists') {
      const lists = filteredLists(h);
      body = '<div class="btn-row"><button class="btn sm" data-act="exportCsv">Exporter en CSV (Excel)</button><button class="btn sm" data-act="loadOlder">Charger plus ancien</button></div>' +
        (lists.length ? '<p class="muted small">' + lists.length + ' liste' + (lists.length > 1 ? 's' : '') + ' · données chargées depuis le ' + esc(fmtDateShort(S.since)) + '</p><div class="stack">' + lists.map((l) => {
          const s = App.summaryOf(l.id); const t = type(l);
          return '<a class="row" href="#/list/' + esc(l.id) + '"><span class="stripe" style="background:' + esc(t.color) + '"></span><span class="main"><span class="title">' + esc(l.name) + ' · ' + esc(fmtDateShort(l.work_date)) + '</span><span class="meta">' + esc(t.name) + ' · <b class="num">' + s.done + '/' + s.total + '</b> terminées' + (s.partial + s.gap_accepted ? ' · ' + (s.partial + s.gap_accepted) + ' écart(s)' : '') + '</span></span>' + ICON.chev + '</a>';
        }).join('') + '</div>' : '<div class="panel empty"><h3>Aucun résultat</h3><p>Élargis les dates ou retire un filtre.</p></div>');
    } else {
      const prod = h.product.trim().toLowerCase(); const emp = h.employee.trim().toLowerCase();
      const ev = S.data.audit.filter((e) => {
        const day = L.ymd(new Date(e.at)); if (day < h.from || day > h.to) return false;
        const list = S.idx.list[e.list_id];
        if (h.type && !(list && list.type_id === h.type)) return false;
        if (prod && !String((e.details && e.details.product) || '').toLowerCase().includes(prod)) return false;
        if (emp && !String(e.actor_name || '').toLowerCase().includes(emp)) return false;
        return true;
      });
      body = ev.length ? '<div class="panel"><div class="timeline">' + ev.slice(0, 300).map((e) => '<div class="' + (/partielle|modification|decision|reouverture/.test(e.action) ? 'alt' : '') + '"><b>' + esc(describeEvent(e)) + '</b><br><span class="muted small">' + esc(e.actor_name || 'Système') + ' · ' + esc(fmtDateTime(e.at)) + '</span></div>').join('') + '</div></div>' : '<div class="panel empty"><h3>Aucune action</h3><p>Rien ne correspond à ces filtres.</p></div>';
    }
    return '<div class="head"><div><h1>Historique</h1><p class="sub">Tout ce qui a été demandé, préparé, validé ou signalé.</p></div></div>' + filters + tabs + body;
  };
  App.acts.histTab = (el) => { ui.histTab = el.dataset.t; rerender(); };
  App.acts.histReset = () => { ui.hist = null; rerender(); };
  App.acts.form_histFilter = (f) => { ui.hist = { from: f.from.value || shiftDate(today(), -13), to: f.to.value || today(), type: f.type.value, product: f.product.value, employee: f.employee.value }; rerender(); };
  App.acts.loadOlder = async () => { S.since = shiftDate(S.since, -90); toast('Chargement…'); await App.reload(false); toast('Données chargées depuis le ' + fmtDateShort(S.since) + '.', 'good'); };
  App.acts.exportCsv = () => {
    const h = histFilters(); const rows = [['Date', 'Liste', 'Type', 'Produit', 'Demandé', 'Unité', 'Préparé', 'Manquant', 'Surplus', 'Statut', 'Motif', 'Commentaire', 'Consigne manager', 'Employé', 'Heure']];
    filteredLists(h).forEach((l) => (S.idx.itemsByList[l.id] || []).forEach((i) => {
      const r = S.idx.result[i.id]; const rep = S.idx.reportByItem[i.id];
      rows.push([l.work_date, l.name, type(l).name, i.product, i.requested_qty, i.unit, r && r.prepared_qty != null ? r.prepared_qty : '', r ? r.missing_qty : '', r ? r.surplus_qty : '', L.STATUS[r ? r.status : 'todo'].label, rep ? rep.reason : '', (r && r.comment) || (rep && rep.comment) || '', (r && r.manager_instruction) || '', r ? r.completed_by_name || r.updated_by_name || '' : '', r && r.updated_at ? fmtTime(r.updated_at) : '']);
    }));
    const csv = '﻿' + rows.map((r) => r.map((c) => L.csvCell(typeof c === 'number' ? String(c).replace('.', ',') : c)).join(';')).join('\r\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' })); a.download = 'pokawa-historique-' + h.from + '_' + h.to + '.csv';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast((rows.length - 1) + ' ligne(s) exportée(s).', 'good');
  };

  // ================================================================ ÉQUIPE (administrateur)
  App.views.m_team = function () {
    if (!App.isAdmin()) return '<div class="banner warn">Réservé aux administrateurs.</div>';
    const people = S.data.profiles.slice().sort((a, b) => (b.active - a.active) || a.full_name.localeCompare(b.full_name));
    const form = ui.teamNew ? '<form class="panel" data-form="newAccount"><h2>Nouveau compte</h2><div class="grid2">' +
      '<label class="field"><span>Nom</span><input type="text" name="full_name" required placeholder="Ex. Emma Durand"></label>' +
      '<label class="field"><span>Identifiant de connexion</span><input type="text" name="username" required autocapitalize="none" placeholder="Ex. emma"><small>Lettres, chiffres, point, tiret.</small></label>' +
      '<label class="field"><span>Rôle</span><select name="role"><option value="employee">Employé</option><option value="manager">Manager</option><option value="admin">Administrateur</option></select></label>' +
      '<label class="field"><span>Mot de passe provisoire</span><input type="text" name="password" required minlength="8" autocomplete="off"><small><button type="button" class="btn sm" data-act="genPwd">Générer</button> 8 caractères minimum, à communiquer en main propre.</small></label></div>' +
      '<p class="error" id="teamError" role="alert"></p><div class="btn-row"><button type="button" class="btn" data-act="teamToggle">Annuler</button><button class="btn primary" type="submit">Créer le compte</button></div></form>' : '';
    return '<div class="head"><div><h1>Équipe</h1><p class="sub">Comptes, rôles et accès.</p></div><button class="btn primary" data-act="teamToggle">Nouveau compte</button></div>' + form +
      '<div class="stack">' + people.map((p) => '<div class="panel" style="' + (p.active ? '' : 'opacity:.7') + '"><div class="head"><div><h3>' + esc(p.full_name) + (p.id === S.user.id ? ' <span class="muted small">(toi)</span>' : '') + '</h3><p class="muted small">' + (p.active ? 'Compte actif' : 'Compte désactivé') + '</p></div>' +
        '<select data-change="profileRole" data-id="' + esc(p.id) + '" style="width:auto" aria-label="Rôle de ' + esc(p.full_name) + '">' + Object.entries(ROLE).map(([k, v]) => '<option value="' + k + '" ' + (p.role === k ? 'selected' : '') + '>' + esc(v) + '</option>').join('') + '</select></div>' +
        '<div class="btn-row"><button class="btn sm ' + (p.active ? 'danger' : '') + '" data-act="toggleActive" data-id="' + esc(p.id) + '">' + (p.active ? 'Désactiver' : 'Réactiver') + '</button><button class="btn sm" data-act="resetPwd" data-id="' + esc(p.id) + '">Nouveau mot de passe</button></div></div>').join('') + '</div>';
  };
  App.acts.teamToggle = () => { ui.teamNew = !ui.teamNew; rerender(); };
  App.acts.genPwd = (el) => { const f = el.closest('form'); const a = 'abcdefghjkmnpqrstuvwxyz23456789'; f.password.value = Array.from(crypto.getRandomValues(new Uint8Array(10)), (x) => a[x % a.length]).join(''); };
  App.acts.form_newAccount = async (f) => {
    const btn = $('[type=submit]', f); btn.disabled = true;
    try { await Backend.createAccount({ username: f.username.value, full_name: f.full_name.value, role: f.role.value, password: f.password.value }); ui.teamNew = false; toast('Compte créé. Communique l’identifiant et le mot de passe à la personne.', 'good'); await App.reload(true); }
    catch (err) { $('#teamError').textContent = err.message; btn.disabled = false; }
  };
  App.acts.profileRole = async (el) => { try { await Backend.saveProfile(el.dataset.id, { role: el.value }); toast('Rôle modifié.', 'good'); } catch (err) { toast(err.message, 'bad'); } await App.reload(true); };
  App.acts.toggleActive = async (el) => {
    const p = S.idx.profile[el.dataset.id];
    if (p.active && !(await confirmBox(p.full_name + ' ne pourra plus se connecter. Son historique est conservé.', { title: 'Désactiver ce compte ?', ok: 'Désactiver', danger: true }))) return;
    await Backend.saveProfile(p.id, { active: !p.active }); toast(p.active ? 'Compte désactivé.' : 'Compte réactivé.', 'good'); await App.reload(true);
  };
  App.acts.resetPwd = (el) => {
    const p = S.idx.profile[el.dataset.id];
    openSheet('<div><h2>Nouveau mot de passe</h2><p class="muted">' + esc(p.full_name) + '</p></div><form data-form="resetPwd" data-id="' + esc(p.id) + '" class="stack"><label class="field"><span>Mot de passe provisoire</span><input type="text" name="password" required minlength="8" autocomplete="off" autofocus></label><p class="error" id="pwdError"></p>' +
      '<div class="btn-row"><button type="button" class="btn" data-act="closeSheet">Annuler</button><button class="btn primary" type="submit" style="flex:1">Enregistrer</button></div></form>');
  };
  App.acts.form_resetPwd = async (f) => { try { await Backend.resetPassword(f.dataset.id, f.password.value); closeSheet(); toast('Mot de passe modifié.', 'good'); } catch (err) { $('#pwdError').textContent = err.message; } };

  // ================================================================ RÉGLAGES
  App.views.m_settings = function () {
    const types = S.data.types.slice().sort((a, b) => a.sort_order - b.sort_order);
    return '<div class="head"><div><h1>Réglages</h1><p class="sub">Types de listes et règles de contrôle.</p></div></div>' +
      '<div class="panel"><h2>Types de listes</h2><p class="muted small">Crée tes propres types (nettoyage, ouverture, livraison…) sans toucher au code.</p><div class="stack">' +
      types.map((t) => '<form class="item-edit" style="grid-template-columns:44px 1fr auto auto" data-form="saveType" data-id="' + esc(t.id) + '"><input type="color" name="color" value="' + esc(t.color) + '" aria-label="Couleur" style="padding:2px;min-height:48px"><input type="text" name="name" value="' + esc(t.name) + '" aria-label="Nom" required>' +
        '<label style="display:flex;gap:6px;align-items:center;min-height:48px"><input type="checkbox" name="active" ' + (t.active ? 'checked' : '') + ' style="width:20px;min-height:20px"> Actif</label><button class="btn sm primary" type="submit">Enregistrer</button></form>').join('') +
      '<form class="item-edit" style="grid-template-columns:44px 1fr auto" data-form="saveType" data-id=""><input type="color" name="color" value="#0B3C5D" aria-label="Couleur" style="padding:2px;min-height:48px"><input type="text" name="name" placeholder="Nouveau type de liste" aria-label="Nom du nouveau type" required><button class="btn sm primary" type="submit">Ajouter</button></form></div></div>' +
      '<div class="panel"><h2>Règles appliquées automatiquement</h2><ul style="margin:0;padding-left:20px;display:grid;gap:6px"><li>Une quantité préparée inférieure à la demande ne peut pas être validée : une raison est obligatoire (commentaire obligatoire pour « Autre raison »).</li><li>Les employés ne peuvent jamais modifier une quantité demandée, ni une consigne.</li><li>Une exception acceptée par le management reste marquée comme écart, jamais comme « terminé ».</li><li>Chaque validation, écart, décision et modification après publication est conservé dans l’historique.</li><li>' + (App.LIVE ? 'Ces règles sont vérifiées par la base de données, pas seulement par l’écran.' : 'Mode démo : ces règles sont appliquées sur cet appareil, comme le fera le serveur en mode réel.') + '</li></ul></div>' +
      (!App.LIVE && App.isAdmin() ? '<div class="panel"><h2>Données de démonstration</h2><p class="muted small">Remet les listes et comptes d’exemple à leur état de départ.</p><div class="btn-row"><button class="btn danger" data-act="resetDemo">Réinitialiser la démo</button></div></div>' : '');
  };
  App.acts.form_saveType = async (f) => {
    await Backend.saveType({ id: f.dataset.id || null, name: f.name.value, color: f.color.value, active: f.active ? f.active.checked : true });
    toast('Type enregistré.', 'good'); await App.reload(true);
  };
  App.acts.resetDemo = async () => {
    if (!(await confirmBox('Toutes les données de démonstration seront remplacées par les exemples de départ.', { title: 'Réinitialiser la démo ?', ok: 'Réinitialiser', danger: true }))) return;
    await Backend.resetDemo(); toast('Démo réinitialisée.', 'good'); await App.reload(true);
  };
})();
