/* Pokawa Ops — règles métier partagées.
 * Ce fichier ne touche ni au DOM ni au réseau : il est testé avec Node (tests/logic.test.js)
 * et utilisé tel quel par le mode démo. Les mêmes règles sont réécrites en SQL dans
 * supabase/schema.sql (fonction submit_item_result) pour être imposées côté serveur.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Logic = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const OTHER_REASON = 'Autre raison';
  const REASONS = [
    'Rupture de stock',
    'Quantité insuffisante à la livraison',
    'Problème de production',
    'Manque de temps',
    'Problème matériel',
    OTHER_REASON
  ];

  const UNITS = ['kg', 'g', 'L', 'ml', 'pièce', 'bac', 'bouteille', 'sachet', 'boîte'];

  // Libellés et couleurs : une seule source pour toute l'application.
  const STATUS = {
    todo:         { label: 'À faire',                          short: 'À faire',     color: '#5B6B76', soft: '#E9EEF1' },
    in_progress:  { label: 'En cours',                         short: 'En cours',    color: '#1F63B5', soft: '#E1EBF8' },
    done:         { label: 'Terminé',                          short: 'Terminé',     color: '#16784B', soft: '#DDF1E6' },
    partial:      { label: 'Production partielle — en attente du management', short: 'Partiel', color: '#B96A00', soft: '#FBEBCF' },
    to_fix:       { label: 'À corriger',                       short: 'À corriger',  color: '#C0322B', soft: '#FADEDB' },
    gap_accepted: { label: 'Écart accepté par le management',  short: 'Écart accepté', color: '#6B45A8', soft: '#ECE4F7' }
  };
  const STATUS_ORDER = ['todo', 'in_progress', 'partial', 'to_fix', 'done', 'gap_accepted'];
  const FINAL_STATUSES = ['done', 'gap_accepted'];
  // Statuts depuis lesquels un employé peut (re)envoyer une quantité.
  const SUBMITTABLE = ['todo', 'in_progress', 'to_fix', 'partial'];

  const DECISIONS = {
    complete:    { label: 'Demander de compléter',            item: 'to_fix',       resolves: false, noteRequired: false },
    recheck:     { label: 'Demander une nouvelle vérification', item: 'to_fix',     resolves: false, noteRequired: false },
    instruction: { label: 'Ajouter une consigne',             item: 'partial',      resolves: false, noteRequired: true  },
    accept:      { label: 'Accepter exceptionnellement l’écart', item: 'gap_accepted', resolves: true, noteRequired: true },
    close:       { label: 'Clôturer avec une justification',  item: 'gap_accepted', resolves: true,  noteRequired: true }
  };

  const round3 = (n) => Math.round(n * 1000) / 1000;

  /** "12", "12,5", " 12.5 ", 12 → nombre ; sinon NaN. Refuse négatifs et texte. */
  function parseQty(value) {
    if (typeof value === 'number') return Number.isFinite(value) && value >= 0 ? round3(value) : NaN;
    const s = String(value == null ? '' : value).trim().replace(/\s/g, '').replace(',', '.');
    if (!/^\d+(\.\d+)?$/.test(s)) return NaN;
    return round3(Number(s));
  }

  function fmtQty(n) {
    if (!Number.isFinite(n)) return '—';
    return round3(n).toLocaleString('fr-FR', { maximumFractionDigits: 3 });
  }

  /** Compare demandé / préparé. kind: equal | surplus | shortfall | invalid */
  function compare(requested, prepared) {
    const r = parseQty(requested);
    const p = parseQty(prepared);
    if (Number.isNaN(r) || Number.isNaN(p)) return { kind: 'invalid', requested: r, prepared: p, diff: NaN };
    const diff = round3(p - r);
    if (diff === 0) return { kind: 'equal', requested: r, prepared: p, diff: 0 };
    return { kind: diff > 0 ? 'surplus' : 'shortfall', requested: r, prepared: p, diff };
  }

  /**
   * Règle centrale : que se passe-t-il quand l'employé envoie sa quantité ?
   * surplusPolicy : 'allow' (valide et signale) | 'justify' (commentaire obligatoire)
   */
  function evaluateSubmission({ requested, prepared, reason, comment, surplusPolicy }) {
    const c = compare(requested, prepared);
    const cleanReason = (reason || '').trim();
    const cleanComment = (comment || '').trim();
    if (c.kind === 'invalid') {
      return { ok: false, code: 'invalid_quantity', error: 'Saisis une quantité valide (nombre positif, par exemple 12 ou 12,5).' };
    }
    if (c.kind === 'shortfall') {
      if (!cleanReason) return { ok: false, code: 'reason_required', error: 'Choisis une raison pour expliquer la quantité manquante.', missing: -c.diff };
      if (!REASONS.includes(cleanReason)) return { ok: false, code: 'reason_invalid', error: 'Cette raison n’existe pas.' };
      if (cleanReason === OTHER_REASON && cleanComment.length < 3) {
        return { ok: false, code: 'comment_required', error: 'Explique la raison dans le commentaire.' };
      }
      return { ok: true, status: 'partial', missing: -c.diff, surplus: 0, needsReport: true, reason: cleanReason, comment: cleanComment, prepared: c.prepared, requested: c.requested };
    }
    if (c.kind === 'surplus') {
      if (surplusPolicy === 'justify' && cleanComment.length < 3) {
        return { ok: false, code: 'surplus_comment_required', error: 'Ajoute un commentaire : la quantité préparée dépasse la demande.', surplus: c.diff };
      }
      return { ok: true, status: 'done', missing: 0, surplus: c.diff, needsReport: false, reason: null, comment: cleanComment || null, prepared: c.prepared, requested: c.requested };
    }
    return { ok: true, status: 'done', missing: 0, surplus: 0, needsReport: false, reason: null, comment: cleanComment || null, prepared: c.prepared, requested: c.requested };
  }

  function canSubmitFrom(status) { return SUBMITTABLE.includes(status); }

  /** Vérifie une décision du management et renvoie son effet. */
  function evaluateDecision(decision, note) {
    const d = DECISIONS[decision];
    if (!d) return { ok: false, error: 'Décision inconnue.' };
    if (d.noteRequired && String(note || '').trim().length < 3) {
      return { ok: false, error: 'Ajoute une justification ou une consigne pour cette décision.' };
    }
    return { ok: true, itemStatus: d.item, resolves: d.resolves };
  }

  /** Synthèse d'une liste à partir des statuts de ses lignes. */
  function summarize(statuses, openReports) {
    const counts = { todo: 0, in_progress: 0, done: 0, partial: 0, to_fix: 0, gap_accepted: 0 };
    statuses.forEach((s) => { counts[counts[s] === undefined ? 'todo' : s] += 1; });
    const total = statuses.length;
    const remaining = counts.todo + counts.in_progress + counts.partial + counts.to_fix;
    return {
      total, ...counts, remaining,
      waitingManager: counts.partial,
      reports: openReports || 0,
      pct: total ? Math.round((counts.done / total) * 100) : 0,
      finished: total > 0 && remaining === 0
    };
  }

  /** Une liste est en retard si elle a une heure limite dépassée (jour J) ou si sa date est passée, avec du travail restant. */
  function isOverdue(list, remaining, now) {
    if (!remaining || list.status !== 'published') return false;
    const d = now || new Date();
    const today = ymd(d);
    if (list.work_date < today) return true;
    if (list.work_date > today || !list.due_time) return false;
    const [h, m] = String(list.due_time).split(':').map(Number);
    return d.getHours() * 60 + d.getMinutes() > h * 60 + (m || 0);
  }

  function ymd(d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  function csvCell(v) {
    const s = v == null ? '' : String(v);
    return /[";\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  return {
    OTHER_REASON, REASONS, UNITS, STATUS, STATUS_ORDER, FINAL_STATUSES, SUBMITTABLE, DECISIONS,
    parseQty, fmtQty, compare, evaluateSubmission, canSubmitFrom, evaluateDecision,
    summarize, isOverdue, ymd, csvCell
  };
});
