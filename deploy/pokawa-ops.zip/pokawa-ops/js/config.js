/* Configuration de Pokawa Ops.
 *
 * Mode démo : laissez SUPABASE_URL et SUPABASE_ANON_KEY vides. L'application fonctionne
 * entièrement sur l'appareil (données dans le navigateur) avec trois comptes d'essai.
 *
 * Mode réel : collez l'URL du projet et la clé « anon / publishable » (Supabase →
 * Project Settings → API). Cette clé est publique par conception : la protection vient
 * des règles de sécurité de supabase/schema.sql. N'écrivez JAMAIS ici la clé service_role.
 */
window.POKAWA_CONFIG = {
  SUPABASE_URL: '',
  SUPABASE_ANON_KEY: '',
  // Les employés se connectent avec un identifiant simple (ex. « emma »), sans e-mail.
  // Il est converti en emma@<AUTH_DOMAIN> ; doit être identique dans la fonction admin-users.
  AUTH_DOMAIN: 'pokawa-ops.local',
  RESTAURANT: 'Pokawa'
};
