/* Backend « démo » : même interface que backend-supabase.js, données dans localStorage.
 * Il applique exactement les mêmes règles que le serveur (via Logic) pour que la démo
 * se comporte comme la version réelle. Les mots de passe de démo ne sont PAS protégés :
 * ne jamais y saisir de vrais mots de passe.
 */
(function () {
  'use strict';
  const L = window.Logic;
  const KEY = 'pokawa-ops-demo-v1';
  const SESSION = 'pokawa-ops-demo-session';
  const uuid = () => (crypto.randomUUID ? crypto.randomUUID() : 'id-' + Date.now() + '-' + Math.random().toString(16).slice(2));
  const nowIso = () => new Date().toISOString();
  const fail = (msg) => { throw new Error(msg); };
  const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };

  function seed() {
    const today = L.ymd(new Date());
    const yesterday = L.ymd(addDays(new Date(), -1));
    const users = [
      { id: 'u-admin', username: 'admin', password: 'admin1234', full_name: 'Alice Martin (admin)', role: 'admin', active: true },
      { id: 'u-manager', username: 'manager', password: 'manager1234', full_name: 'Marc Dubois (manager)', role: 'manager', active: true },
      { id: 'u-emma', username: 'emma', password: 'emma1234', full_name: 'Emma Leroy', role: 'employee', active: true },
      { id: 'u-karim', username: 'karim', password: 'karim1234', full_name: 'Karim Benali', role: 'employee', active: true }
    ];
    const typeDefs = [
      ['Inventaire', '#1F63B5'], ['Production du matin', '#0B7A75'], ['Production de l’après-midi', '#B96A00'],
      ['Point de production', '#6B45A8'], ['Préparation avant service', '#C0322B'], ['Contrôle des stocks', '#4C6A00'],
      ['Nettoyage', '#5B6B76'], ['Contrôle de fin de service', '#0B3C5D']
    ];
    const types = typeDefs.map(([name, color], i) => ({ id: 't-' + i, name, color, sort_order: i, active: true }));
    const T = (name) => types.find((t) => t.name === name).id;
    const mkList = (id, name, type, date, period, due, status, extra) => ({
      id, name, type_id: T(type), work_date: date, period, due_time: due, instructions: '', surplus_policy: 'justify',
      status, created_by: 'u-manager', created_at: nowIso(), published_at: status === 'draft' ? null : nowIso(), updated_at: nowIso(), ...extra
    });
    const lists = [
      mkList('l-morning', 'Production du matin', 'Production du matin', today, 'morning', '11:00', 'published',
        { instructions: 'Étiqueter chaque bac avec la date et l’heure de préparation.' }),
      mkList('l-afternoon', 'Production de l’après-midi', 'Production de l’après-midi', today, 'afternoon', '16:00', 'published'),
      mkList('l-inventory', 'Inventaire de fin de semaine', 'Inventaire', today, 'evening', '21:00', 'draft'),
      mkList('l-yesterday', 'Production du matin', 'Production du matin', yesterday, 'morning', '11:00', 'closed')
    ];
    const rows = (listId, arr) => arr.map(([product, qty, unit], i) => ({ id: listId + '-' + i, list_id: listId, product, requested_qty: qty, unit, comment: '', sort_order: i }));
    const items = [
      ...rows('l-morning', [['Riz', 12, 'kg'], ['Sauce fromagère', 4, 'L'], ['Guacamole', 6, 'bac'], ['Saumon mariné', 5, 'kg'], ['Edamame', 3, 'kg'],
        ['Mangue', 2, 'kg'], ['Concombre', 3, 'kg'], ['Chou rouge', 2, 'kg'], ['Poulet teriyaki', 4, 'kg'], ['Gingembre mariné', 1, 'kg']]),
      ...rows('l-afternoon', [['Bubble fraise', 3, 'bac'], ['Coulis mangue', 2, 'L'], ['Riz', 6, 'kg']]),
      ...rows('l-inventory', [['Riz', 20, 'kg'], ['Saumon surgelé', 10, 'kg'], ['Avocat', 30, 'pièce']]),
      ...rows('l-yesterday', [['Riz', 12, 'kg'], ['Sauce fromagère', 4, 'L'], ['Guacamole', 6, 'bac']])
    ];
    const y = (iso) => new Date(addDays(new Date(), -1).setHours(iso, 20, 0, 0)).toISOString();
    const results = [
      { item_id: 'l-yesterday-0', status: 'done', prepared_qty: 12, missing_qty: 0, surplus_qty: 0, comment: null, manager_instruction: null, updated_by_name: 'Emma Leroy', updated_at: y(9), completed_by_name: 'Emma Leroy', completed_at: y(9) },
      { item_id: 'l-yesterday-1', status: 'gap_accepted', prepared_qty: 3, missing_qty: 1, surplus_qty: 0, comment: null, manager_instruction: 'Livraison en retard, accepté.', updated_by_name: 'Marc Dubois (manager)', updated_at: y(10), completed_by_name: null, completed_at: null },
      { item_id: 'l-yesterday-2', status: 'done', prepared_qty: 6, missing_qty: 0, surplus_qty: 0, comment: null, manager_instruction: null, updated_by_name: 'Karim Benali', updated_at: y(10), completed_by_name: 'Karim Benali', completed_at: y(10) }
    ];
    const reports = [{
      id: 'r-yesterday', item_id: 'l-yesterday-1', list_id: 'l-yesterday', requested_qty: 4, prepared_qty: 3, missing_qty: 1, reason: 'Quantité insuffisante à la livraison',
      comment: null, reported_by: 'u-karim', reported_by_name: 'Karim Benali', reported_at: y(9), status: 'resolved', decision: 'accept',
      decision_note: 'Livraison en retard, accepté.', decided_by: 'u-manager', decided_by_name: 'Marc Dubois (manager)', decided_at: y(10)
    }];
    const audit = [
      { id: 1, at: y(8), actor_name: 'Marc Dubois (manager)', action: 'publication', entity: 'list', entity_id: 'l-yesterday', list_id: 'l-yesterday', details: { name: 'Production du matin' } },
      { id: 2, at: y(9), actor_name: 'Karim Benali', action: 'validation_partielle', entity: 'list_item', entity_id: 'l-yesterday-1', list_id: 'l-yesterday',
        details: { product: 'Sauce fromagère', unit: 'L', requested: 4, prepared: 3, missing: 1, reason: 'Quantité insuffisante à la livraison' } },
      { id: 3, at: y(10), actor_name: 'Marc Dubois (manager)', action: 'decision_accept', entity: 'report', entity_id: 'r-yesterday', list_id: 'l-yesterday',
        details: { product: 'Sauce fromagère', note: 'Livraison en retard, accepté.' } }
    ];
    return { users, types, lists, items, results, reports, audit, nextAudit: 4 };
  }

  let cache = null;
  function read() {
    if (cache) return cache;
    try { cache = JSON.parse(localStorage.getItem(KEY)); } catch (e) { cache = null; }
    if (!cache) { cache = seed(); write(cache); }
    return cache;
  }
  function write(s) { cache = s; localStorage.setItem(KEY, JSON.stringify(s)); }
  // Relit toujours le stockage (un autre onglet a pu écrire).
  function fresh() { cache = null; return read(); }

  let me = null;
  const current = (s) => {
    const id = me && me.id;
    const u = s.users.find((x) => x.id === id);
    if (!u || !u.active) fail('Compte inactif ou non autorisé.');
    return u;
  };
  const needManager = (s) => { const u = current(s); if (u.role === 'employee') fail('Réservé au management.'); return u; };
  const needAdmin = (s) => { const u = current(s); if (u.role !== 'admin') fail('Réservé aux administrateurs.'); return u; };
  const log = (s, u, action, entity, entityId, listId, details) =>
    s.audit.unshift({ id: s.nextAudit++, at: nowIso(), actor_name: u ? u.full_name : null, action, entity, entity_id: entityId, list_id: listId, details: details || {} });
  const publicUser = (u) => ({ id: u.id, username: u.username, full_name: u.full_name, role: u.role, active: u.active });

  const Backend = {
    mode: 'demo',
    demoAccounts: [
      { username: 'manager', password: 'manager1234', label: 'Manager' },
      { username: 'emma', password: 'emma1234', label: 'Employée (Emma)' },
      { username: 'admin', password: 'admin1234', label: 'Administrateur' }
    ],
    async init() {
      const id = sessionStorage.getItem(SESSION);
      const s = fresh();
      const u = s.users.find((x) => x.id === id && x.active);
      me = u ? publicUser(u) : null;
      return me;
    },
    async signIn(username, password) {
      const s = fresh();
      const u = s.users.find((x) => x.username === String(username).trim().toLowerCase());
      if (!u || u.password !== password) fail('Identifiant ou mot de passe incorrect.');
      if (!u.active) fail('Ce compte est désactivé. Demande à un administrateur de le réactiver.');
      sessionStorage.setItem(SESSION, u.id);
      me = publicUser(u);
      return me;
    },
    async signOut() { sessionStorage.removeItem(SESSION); me = null; },

    async load() {
      const s = fresh();
      const u = current(s);
      const manager = u.role !== 'employee';
      const week = L.ymd(addDays(new Date(), -7));
      const lists = s.lists.filter((l) => manager || (l.status === 'published' && l.work_date >= week));
      const ids = new Set(lists.map((l) => l.id));
      const items = s.items.filter((i) => ids.has(i.list_id));
      const itemIds = new Set(items.map((i) => i.id));
      return clone({
        profiles: s.users.filter((x) => manager || x.id === u.id).map(publicUser),
        types: s.types, lists, items,
        results: s.results.filter((r) => itemIds.has(r.item_id)),
        reports: s.reports.filter((r) => manager || r.reported_by === u.id),
        audit: manager ? s.audit.slice(0, 600) : []
      });
    },
    subscribe(cb) {
      const onStorage = (e) => { if (e.key === KEY) { cache = null; cb(); } };
      window.addEventListener('storage', onStorage);
      return () => window.removeEventListener('storage', onStorage);
    },

    // ---------- employé ----------
    async startItem(itemId) {
      const s = fresh(); const u = current(s);
      const item = s.items.find((i) => i.id === itemId) || fail('Ligne introuvable.');
      const list = s.lists.find((l) => l.id === item.list_id);
      if (list.status !== 'published') fail('Cette liste n’est pas ouverte à la saisie.');
      let r = s.results.find((x) => x.item_id === itemId);
      if (!r) { r = blank(itemId); s.results.push(r); }
      if (r.status === 'todo') {
        r.status = 'in_progress'; r.updated_by_name = u.full_name; r.updated_at = nowIso();
        log(s, u, 'demarrage', 'list_item', itemId, list.id, { product: item.product });
      }
      write(s);
    },
    async submitResult(itemId, prepared, reason, comment) {
      const s = fresh(); const u = current(s);
      const item = s.items.find((i) => i.id === itemId) || fail('Ligne introuvable.');
      const list = s.lists.find((l) => l.id === item.list_id);
      if (list.status !== 'published') fail('Cette liste n’est pas ouverte à la saisie.');
      let r = s.results.find((x) => x.item_id === itemId);
      if (r && !L.canSubmitFrom(r.status)) fail('Cette ligne est déjà validée. Seul un manager peut la rouvrir.');
      const ev = L.evaluateSubmission({ requested: item.requested_qty, prepared, reason, comment, surplusPolicy: list.surplus_policy });
      if (!ev.ok) fail(ev.error);
      if (!r) { r = blank(itemId); s.results.push(r); }
      Object.assign(r, {
        status: ev.status, prepared_qty: ev.prepared, missing_qty: ev.missing, surplus_qty: ev.surplus, comment: ev.comment,
        updated_by_name: u.full_name, updated_at: nowIso(),
        completed_by_name: ev.status === 'done' ? u.full_name : null, completed_at: ev.status === 'done' ? nowIso() : null
      });
      const open = s.reports.find((x) => x.item_id === itemId && x.status === 'open');
      if (ev.needsReport) {
        if (open) Object.assign(open, { prepared_qty: ev.prepared, missing_qty: ev.missing, reason: ev.reason, comment: ev.comment, reported_by: u.id, reported_by_name: u.full_name, reported_at: nowIso() });
        else s.reports.push({ id: uuid(), item_id: itemId, list_id: list.id, requested_qty: item.requested_qty, prepared_qty: ev.prepared, missing_qty: ev.missing,
          reason: ev.reason, comment: ev.comment, reported_by: u.id, reported_by_name: u.full_name, reported_at: nowIso(), status: 'open',
          decision: null, decision_note: null, decided_by: null, decided_by_name: null, decided_at: null });
        log(s, u, 'validation_partielle', 'list_item', itemId, list.id, { product: item.product, unit: item.unit, requested: item.requested_qty, prepared: ev.prepared, missing: ev.missing, reason: ev.reason, comment: ev.comment });
      } else {
        if (open) Object.assign(open, { status: 'resolved', decision: 'completed', decision_note: 'Production complétée par l’employé.', decided_at: nowIso() });
        log(s, u, ev.surplus > 0 ? 'validation_surplus' : 'validation', 'list_item', itemId, list.id, { product: item.product, unit: item.unit, requested: item.requested_qty, prepared: ev.prepared, surplus: ev.surplus, comment: ev.comment });
      }
      write(s);
    },

    // ---------- management ----------
    async saveList(list, items) {
      const s = fresh(); const u = needManager(s);
      if (!String(list.name || '').trim()) fail('Donne un nom à la liste.');
      if (!items.length) fail('Ajoute au moins un produit.');
      items.forEach((it, n) => {
        if (!String(it.product || '').trim()) fail('Ligne ' + (n + 1) + ' : indique le produit.');
        const q = L.parseQty(it.requested_qty);
        if (!(q > 0)) fail('Ligne ' + (n + 1) + ' : la quantité demandée doit être supérieure à 0.');
        if (!String(it.unit || '').trim()) fail('Ligne ' + (n + 1) + ' : indique l’unité.');
      });
      let row = list.id && s.lists.find((l) => l.id === list.id);
      const published = row && row.status === 'published';
      if (!row) {
        row = { id: uuid(), status: 'draft', created_by: u.id, created_at: nowIso(), published_at: null };
        s.lists.push(row);
        log(s, u, 'creation_liste', 'list', row.id, row.id, { name: list.name });
      } else if (published) {
        const changed = ['name', 'work_date', 'instructions', 'due_time', 'surplus_policy'].some((k) => (row[k] || null) !== (list[k] || null));
        if (changed) log(s, u, 'modification_apres_publication', 'list', row.id, row.id, { name: list.name });
      }
      Object.assign(row, {
        name: list.name.trim(), type_id: list.type_id || null, work_date: list.work_date, period: list.period, due_time: list.due_time || null,
        instructions: (list.instructions || '').trim(), surplus_policy: list.surplus_policy || 'justify', updated_at: nowIso()
      });
      const before = s.items.filter((i) => i.list_id === row.id);
      const keep = new Set(items.filter((i) => i.id).map((i) => i.id));
      before.filter((i) => !keep.has(i.id)).forEach((i) => {
        if (published) log(s, u, 'modification_apres_publication', 'list_item', i.id, row.id, { operation: 'DELETE', product: i.product, old_qty: i.requested_qty, unit: i.unit });
        s.results = s.results.filter((r) => r.item_id !== i.id);
        s.reports = s.reports.filter((r) => r.item_id !== i.id);
      });
      s.items = s.items.filter((i) => i.list_id !== row.id || keep.has(i.id));
      items.forEach((it, n) => {
        const qty = L.parseQty(it.requested_qty);
        const existing = it.id && s.items.find((i) => i.id === it.id);
        if (existing) {
          if (published && (existing.requested_qty !== qty || existing.product !== it.product.trim() || existing.unit !== it.unit.trim())) {
            log(s, u, 'modification_apres_publication', 'list_item', existing.id, row.id, { operation: 'UPDATE', product: it.product.trim(), old_qty: existing.requested_qty, new_qty: qty, unit: it.unit.trim() });
          }
          Object.assign(existing, { product: it.product.trim(), requested_qty: qty, unit: it.unit.trim(), comment: (it.comment || '').trim(), sort_order: n });
        } else {
          const ni = { id: uuid(), list_id: row.id, product: it.product.trim(), requested_qty: qty, unit: it.unit.trim(), comment: (it.comment || '').trim(), sort_order: n };
          s.items.push(ni);
          if (published) log(s, u, 'modification_apres_publication', 'list_item', ni.id, row.id, { operation: 'INSERT', product: ni.product, new_qty: qty, unit: ni.unit });
        }
      });
      write(s);
      return row.id;
    },
    async setListStatus(listId, status) {
      const s = fresh(); const u = needManager(s);
      const list = s.lists.find((l) => l.id === listId) || fail('Liste introuvable.');
      if (status === 'published' && !s.items.some((i) => i.list_id === listId)) fail('Ajoute au moins un produit avant de publier.');
      if (status === 'draft') {
        const ids = new Set(s.items.filter((i) => i.list_id === listId).map((i) => i.id));
        if (s.results.some((r) => ids.has(r.item_id) && r.status !== 'todo')) fail('Du travail est déjà enregistré : impossible de repasser en brouillon. Clôture la liste à la place.');
      }
      list.status = status; list.updated_at = nowIso();
      if (status === 'published' && !list.published_at) list.published_at = nowIso();
      log(s, u, status === 'published' ? 'publication' : status === 'closed' ? 'cloture' : 'depublication', 'list', listId, listId, { name: list.name });
      write(s);
    },
    async duplicateList(listId, date) {
      const s = fresh(); const u = needManager(s);
      const src = s.lists.find((l) => l.id === listId) || fail('Liste introuvable.');
      const id = uuid();
      s.lists.push({ ...src, id, work_date: date || L.ymd(new Date()), status: 'draft', created_by: u.id, created_at: nowIso(), published_at: null, updated_at: nowIso() });
      s.items.filter((i) => i.list_id === listId).forEach((i) => s.items.push({ ...i, id: uuid(), list_id: id }));
      log(s, u, 'duplication', 'list', id, id, { source: listId, name: src.name });
      write(s);
      return id;
    },
    async decideReport(reportId, decision, note) {
      const s = fresh(); const u = needManager(s);
      const rep = s.reports.find((r) => r.id === reportId) || fail('Signalement introuvable.');
      if (rep.status !== 'open') fail('Ce signalement est déjà clos.');
      const ev = L.evaluateDecision(decision, note);
      if (!ev.ok) fail(ev.error);
      const n = String(note || '').trim() || null;
      Object.assign(rep, { decision, decision_note: n, decided_by: u.id, decided_by_name: u.full_name, decided_at: nowIso(), status: ev.resolves ? 'resolved' : 'open' });
      const r = s.results.find((x) => x.item_id === rep.item_id);
      r.status = ev.itemStatus; r.manager_instruction = n || r.manager_instruction; r.updated_by_name = u.full_name; r.updated_at = nowIso();
      const item = s.items.find((i) => i.id === rep.item_id);
      log(s, u, 'decision_' + decision, 'report', rep.id, rep.list_id, { product: item && item.product, note: n, missing: rep.missing_qty, reason: rep.reason });
      write(s);
    },
    async reopenItem(itemId, note) {
      const s = fresh(); const u = needManager(s);
      const item = s.items.find((i) => i.id === itemId) || fail('Ligne introuvable.');
      let r = s.results.find((x) => x.item_id === itemId);
      if (!r) { r = blank(itemId); s.results.push(r); }
      const n = String(note || '').trim() || null;
      Object.assign(r, { status: 'to_fix', manager_instruction: n || r.manager_instruction, completed_by_name: null, completed_at: null, updated_by_name: u.full_name, updated_at: nowIso() });
      log(s, u, 'reouverture', 'list_item', itemId, item.list_id, { product: item.product, note: n });
      write(s);
    },
    async saveType(type) {
      const s = fresh(); const u = needManager(s);
      const name = String(type.name || '').trim();
      if (!name) fail('Donne un nom au type de liste.');
      if (s.types.some((t) => t.id !== type.id && t.name.toLowerCase() === name.toLowerCase())) fail('Ce type existe déjà.');
      if (type.id) Object.assign(s.types.find((t) => t.id === type.id), { name, color: type.color, active: type.active !== false });
      else s.types.push({ id: uuid(), name, color: type.color || '#0B3C5D', sort_order: s.types.length, active: true });
      log(s, u, 'type_modifie', 'list_type', type.id || null, null, { name });
      write(s);
    },

    // ---------- administration ----------
    async saveProfile(id, patch) {
      const s = fresh(); const u = needAdmin(s);
      const target = s.users.find((x) => x.id === id) || fail('Compte introuvable.');
      if (id === u.id && (patch.active === false || (patch.role && patch.role !== 'admin'))) fail('Tu ne peux pas retirer tes propres droits d’administrateur.');
      Object.assign(target, patch);
      log(s, u, 'compte_modifie', 'profile', id, null, { name: target.full_name, role: target.role, active: target.active });
      write(s);
    },
    async createAccount({ username, full_name, role, password }) {
      const s = fresh(); const u = needAdmin(s);
      const un = String(username || '').trim().toLowerCase();
      if (!/^[a-z0-9._-]{2,32}$/.test(un)) fail('Identifiant : 2 à 32 caractères (lettres, chiffres, . _ -).');
      if (String(full_name || '').trim().length < 2) fail('Indique le nom de la personne.');
      if (String(password || '').length < 8) fail('Le mot de passe doit contenir au moins 8 caractères.');
      if (s.users.some((x) => x.username === un)) fail('Cet identifiant existe déjà.');
      const id = uuid();
      s.users.push({ id, username: un, password, full_name: full_name.trim(), role: role || 'employee', active: true });
      log(s, u, 'compte_cree', 'profile', id, null, { name: full_name.trim(), role });
      write(s);
    },
    async resetPassword(id, password) {
      const s = fresh(); const u = needAdmin(s);
      if (String(password || '').length < 8) fail('Le mot de passe doit contenir au moins 8 caractères.');
      (s.users.find((x) => x.id === id) || fail('Compte introuvable.')).password = password;
      log(s, u, 'mot_de_passe_reinitialise', 'profile', id, null, {});
      write(s);
    },
    async resetDemo() { needAdmin(fresh()); write(seed()); }
  };

  function blank(itemId) {
    return { item_id: itemId, status: 'todo', prepared_qty: null, missing_qty: 0, surplus_qty: 0, comment: null, manager_instruction: null, updated_by_name: null, updated_at: nowIso(), completed_by_name: null, completed_at: null };
  }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  window.LocalBackend = Backend;
})();
